// Talks to the real backend (server.ts + server/routes.ts, backed by
// MySQL — see db/schema.sql). Only the auth token is kept in the browser
// (localStorage); every other piece of clinic data now lives in the
// database and is fetched/saved through this client.

const TOKEN_KEY = "hakeem_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const token = getToken();
  const res = await fetch(`/api${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 401) {
    // Session expired/invalid — force back to the login screen.
    setToken(null);
  }

  let data: any = null;
  try {
    data = await res.json();
  } catch {
    // no JSON body (e.g. 204)
  }

  if (!res.ok) {
    throw new ApiError(data?.error || `Request failed (${res.status})`, res.status);
  }
  return data as T;
}

export const api = {
  login: (username: string, password: string) =>
    request<{ token: string; user: any }>("POST", "/auth/login", { username, password }),

  publicBranding: () => request<any>("GET", "/public/branding"),

  bootstrap: () => request<any>("GET", "/bootstrap"),

  saveSettings: (settings: any) => request<any>("PUT", "/settings", settings),

  addPatient: (patient: any) => request<any>("POST", "/patients", patient),

  addAppointment: (appointment: any) => request<any>("POST", "/appointments", appointment),
  updateAppointmentStatus: (id: string, status: string) =>
    request<{ ok: true }>("PATCH", `/appointments/${id}/status`, { status }),

  addMedicalRecord: (record: any) => request<any>("POST", "/medical-records", record),

  addPrescription: (prescription: any) => request<any>("POST", "/prescriptions", prescription),

  addInvoice: (invoice: any) => request<any>("POST", "/invoices", invoice),
  updateInvoiceStatus: (id: string, status: string, paidAmount: number) =>
    request<{ ok: true }>("PATCH", `/invoices/${id}/status`, { status, paidAmount }),

  addExpense: (expense: any) => request<any>("POST", "/expenses", expense),
  deleteExpense: (id: string) => request<{ ok: true }>("DELETE", `/expenses/${id}`),

  addService: (service: any) => request<any>("POST", "/services", service),
  deleteService: (id: string) => request<{ ok: true }>("DELETE", `/services/${id}`),

  addMedicine: (medicine: any) => request<any>("POST", "/medicines", medicine),
  deleteMedicine: (id: string) => request<{ ok: true }>("DELETE", `/medicines/${id}`),
};

export { ApiError };
