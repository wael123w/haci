-- =====================================================================
-- Hakeem Clinic Management System — MySQL schema (PHP backend edition)
-- Imported automatically by the /install wizard. You never need to open
-- phpMyAdmin yourself unless you want to.
-- =====================================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- settings: a single row (id=1) holding clinic configuration (branding,
-- departments, doctors, AI provider choice, language, etc.) as JSON.
-- User accounts are NOT stored here anymore — see the `users` table
-- below. This keeps the JSON blob to non-sensitive display/config data.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  id INT PRIMARY KEY,
  data JSON NOT NULL
);

-- ---------------------------------------------------------------------
-- users: real relational table (previously a JSON array inside
-- `settings`). UNIQUE on username is enforced by the database itself,
-- so a duplicate account can never be created even if application-level
-- checks are bypassed or buggy.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(64) PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255),
  role VARCHAR(30) NOT NULL DEFAULT 'receptionist',
  specialty VARCHAR(255),
  permissions JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_username (username)
);

-- ---------------------------------------------------------------------
-- login_attempts: append-only log used for rate limiting / lockout on
-- POST /api/auth/login, and available for later security review.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ip_address VARCHAR(64) NOT NULL,
  username VARCHAR(100) NOT NULL,
  success TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_attempts_lookup (ip_address, username, attempted_at)
);

CREATE TABLE IF NOT EXISTS patients (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  age INT,
  gender VARCHAR(20),
  address VARCHAR(255),
  blood_group VARCHAR(10),
  medical_history TEXT,
  created_at VARCHAR(20),
  created_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_patients_name (name)
);

CREATE TABLE IF NOT EXISTS appointments (
  id VARCHAR(64) PRIMARY KEY,
  patient_id VARCHAR(64),
  patient_name VARCHAR(255),
  doctor_name VARCHAR(255),
  date VARCHAR(20),
  time VARCHAR(10),
  status VARCHAR(30),
  type VARCHAR(100),
  notes TEXT,
  price DECIMAL(10,2) DEFAULT 0,
  created_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_appt_date (date),
  INDEX idx_appt_patient (patient_id)
);

CREATE TABLE IF NOT EXISTS medical_records (
  id VARCHAR(64) PRIMARY KEY,
  patient_id VARCHAR(64),
  patient_name VARCHAR(255),
  date VARCHAR(20),
  symptoms TEXT,
  diagnosis TEXT,
  treatment_notes TEXT,
  vitals JSON,
  doctor_name VARCHAR(255),
  created_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_records_patient (patient_id)
);

CREATE TABLE IF NOT EXISTS prescriptions (
  id VARCHAR(64) PRIMARY KEY,
  patient_id VARCHAR(64),
  patient_name VARCHAR(255),
  date VARCHAR(20),
  diagnosis TEXT,
  medications JSON,
  tests JSON,
  advice TEXT,
  doctor_name VARCHAR(255),
  created_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_rx_patient (patient_id)
);

CREATE TABLE IF NOT EXISTS invoices (
  id VARCHAR(64) PRIMARY KEY,
  patient_id VARCHAR(64),
  patient_name VARCHAR(255),
  items JSON,
  total_amount DECIMAL(10,2) DEFAULT 0,
  paid_amount DECIMAL(10,2) DEFAULT 0,
  status VARCHAR(30),
  date VARCHAR(20),
  payment_method VARCHAR(50),
  created_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_invoices_patient (patient_id)
);

CREATE TABLE IF NOT EXISTS expenses (
  id VARCHAR(64) PRIMARY KEY,
  title VARCHAR(255),
  category VARCHAR(100),
  amount DECIMAL(10,2) DEFAULT 0,
  date VARCHAR(20),
  notes TEXT,
  created_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS services (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(255),
  category VARCHAR(100),
  price DECIMAL(10,2) DEFAULT 0,
  duration_minutes INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS medicines (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(255),
  form VARCHAR(100),
  concentration VARCHAR(100),
  stock INT DEFAULT 0,
  price DECIMAL(10,2) DEFAULT 0
);
