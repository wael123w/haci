<?php
// Front controller for every /api/* request. Routed here by the root
// .htaccess. Mirrors server/routes.ts + server.ts (AI routes) 1:1 so the
// existing React frontend (src/utils/api.ts) needs zero changes.

declare(strict_types=1);

require_once __DIR__ . '/../inc/env.php';
require_once __DIR__ . '/../inc/Response.php';
require_once __DIR__ . '/../inc/Database.php';
require_once __DIR__ . '/../inc/Auth.php';
require_once __DIR__ . '/../inc/Validate.php';
require_once __DIR__ . '/../inc/RateLimiter.php';
require_once __DIR__ . '/../inc/SettingsStore.php';
require_once __DIR__ . '/../inc/Ai.php';

// Before install completes, the API must not be reachable — avoids a
// confusing crash if someone hits /api/* on a brand-new upload.
if (!is_file(dirname(__DIR__) . '/install.lock')) {
    Response::json(503, ['error' => 'النظام غير مُثبّت بعد. الرجاء زيارة /install لإكمال التثبيت أولاً.']);
    exit;
}

set_exception_handler(function (Throwable $e) {
    error_log('[hakeem-api] ' . $e->getMessage());
    Response::json(500, ['error' => 'حدث خطأ غير متوقع، حاول مرة أخرى']);
});

header('Content-Type: application/json; charset=utf-8');

$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
// Strip a leading /api so routes below match exactly what routes.ts used.
$path = preg_replace('#^.*?/api#', '', $uri);
$path = rtrim($path, '/');
if ($path === '') {
    $path = '/';
}
$segments = array_values(array_filter(explode('/', $path)));
$body = Response::body();

function newId(string $prefix): string
{
    return $prefix . '-' . (int)(microtime(true) * 1000) . '-' . bin2hex(random_bytes(3));
}

function require_body_valid(array $errors): void
{
    if (!empty($errors)) {
        Validate::fail($errors);
    }
}

// ------------------------------------------------------------------
// Row -> API shape mappers (snake_case columns -> the camelCase shape
// src/types.ts already expects from the previous Node backend).
// ------------------------------------------------------------------
function mapPatient(array $r): array
{
    return [
        'id' => $r['id'], 'name' => $r['name'], 'phone' => $r['phone'],
        'age' => $r['age'] !== null ? (int)$r['age'] : null, 'gender' => $r['gender'],
        'address' => $r['address'], 'bloodGroup' => $r['blood_group'],
        'medicalHistory' => $r['medical_history'], 'createdAt' => $r['created_at'],
    ];
}
function mapAppointment(array $r): array
{
    return [
        'id' => $r['id'], 'patientId' => $r['patient_id'], 'patientName' => $r['patient_name'],
        'doctorName' => $r['doctor_name'], 'date' => $r['date'], 'time' => $r['time'],
        'status' => $r['status'], 'type' => $r['type'], 'notes' => $r['notes'],
        'price' => (float)$r['price'],
    ];
}
function mapMedicalRecord(array $r): array
{
    return [
        'id' => $r['id'], 'patientId' => $r['patient_id'], 'patientName' => $r['patient_name'],
        'date' => $r['date'], 'symptoms' => $r['symptoms'], 'diagnosis' => $r['diagnosis'],
        'treatmentNotes' => $r['treatment_notes'],
        'vitals' => json_decode($r['vitals'] ?? '{}', true) ?: (object)[],
        'doctorName' => $r['doctor_name'],
    ];
}
function mapPrescription(array $r): array
{
    return [
        'id' => $r['id'], 'patientId' => $r['patient_id'], 'patientName' => $r['patient_name'],
        'date' => $r['date'], 'diagnosis' => $r['diagnosis'],
        'medications' => json_decode($r['medications'] ?? '[]', true) ?: [],
        'tests' => json_decode($r['tests'] ?? '[]', true) ?: [],
        'advice' => $r['advice'], 'doctorName' => $r['doctor_name'],
    ];
}
function mapInvoice(array $r): array
{
    return [
        'id' => $r['id'], 'patientId' => $r['patient_id'], 'patientName' => $r['patient_name'],
        'items' => json_decode($r['items'] ?? '[]', true) ?: [],
        'totalAmount' => (float)$r['total_amount'], 'paidAmount' => (float)$r['paid_amount'],
        'status' => $r['status'], 'date' => $r['date'], 'paymentMethod' => $r['payment_method'],
    ];
}
function mapExpense(array $r): array
{
    return [
        'id' => $r['id'], 'title' => $r['title'], 'category' => $r['category'],
        'amount' => (float)$r['amount'], 'date' => $r['date'], 'notes' => $r['notes'],
    ];
}

$DEFAULT_PERMS_BY_ROLE = [
    'admin' => ['dashboard' => true, 'patients' => true, 'appointments' => true, 'records' => true, 'prescriptions' => true, 'billing' => true, 'expenses' => true, 'services' => true, 'medicines' => true, 'settings' => true],
    'doctor' => ['dashboard' => true, 'patients' => true, 'appointments' => true, 'records' => true, 'prescriptions' => true, 'billing' => false, 'expenses' => false, 'services' => true, 'medicines' => true, 'settings' => false],
    'receptionist' => ['dashboard' => true, 'patients' => true, 'appointments' => true, 'records' => false, 'prescriptions' => false, 'billing' => true, 'expenses' => true, 'services' => false, 'medicines' => false, 'settings' => false],
];

// ------------------------------------------------------------------
// Public routes (no session required)
// ------------------------------------------------------------------
if ($method === 'GET' && $path === '/health') {
    Response::json(200, ['status' => 'ok']);
    exit;
}

if ($method === 'POST' && $path === '/auth/login') {
    require_body_valid(Validate::login($body));
    $ip = RateLimiter::clientIp();
    $username = trim((string)$body['username']);

    [$blocked, $wait] = RateLimiter::check($ip, $username);
    if ($blocked) {
        Response::json(429, ['error' => 'محاولات دخول فاشلة كثيرة. الرجاء الانتظار ' . ceil($wait / 60) . ' دقيقة قبل إعادة المحاولة.']);
        exit;
    }

    $user = SettingsStore::findUserByUsername($username);
    // Always run password_verify (even against a dummy hash) so response
    // timing doesn't reveal whether the username exists.
    $dummyHash = '$2y$10$CwTycUXWue0Thq9StjUM0uJ8Ja8v8h7yLg7DZ.h5AN.OK21bY7t0e';
    $match = Auth::verifyPassword((string)$body['password'], $user ? $user['password'] : $dummyHash);

    if (!$user || !$match) {
        RateLimiter::recordAttempt($ip, $username, false);
        Response::json(401, ['error' => 'اسم المستخدم أو كلمة المرور غير صحيحة']);
        exit;
    }

    RateLimiter::recordAttempt($ip, $username, true);
    $permissions = $user['permissions'] ?: ($DEFAULT_PERMS_BY_ROLE[$user['role']] ?? $DEFAULT_PERMS_BY_ROLE['receptionist']);
    $authUser = [
        'id' => $user['id'], 'username' => $user['username'], 'name' => $user['name'],
        'role' => $user['role'], 'specialty' => $user['specialty'], 'permissions' => $permissions,
    ];
    $token = Auth::signToken($authUser);
    Response::json(200, ['token' => $token, 'user' => $authUser]);
    exit;
}

if ($method === 'GET' && $path === '/public/branding') {
    $settings = SettingsStore::getSettingsRow();
    Response::json(200, [
        'clinicName' => $settings['clinicName'] ?? '', 'specialty' => $settings['specialty'] ?? '',
        'clinicLogo' => $settings['clinicLogo'] ?? '', 'loginBackground' => $settings['loginBackground'] ?? '',
        'siteFavicon' => $settings['siteFavicon'] ?? '', 'supportUrl' => $settings['supportUrl'] ?? '',
        'language' => $settings['language'] ?? 'ar', 'customLanguages' => $settings['customLanguages'] ?? [],
    ]);
    exit;
}

// ------------------------------------------------------------------
// Everything below requires a valid session.
// ------------------------------------------------------------------
$user = Auth::requireAuth();

if ($method === 'GET' && $path === '/auth/me') {
    Response::json(200, ['user' => $user]);
    exit;
}

if ($method === 'GET' && $path === '/bootstrap') {
    $pdo = Database::connection();
    $settings = SettingsStore::stripPasswords(SettingsStore::getSettingsRow());
    $patients = array_map('mapPatient', $pdo->query("SELECT * FROM patients ORDER BY created_ts DESC")->fetchAll());
    $appointments = array_map('mapAppointment', $pdo->query("SELECT * FROM appointments ORDER BY created_ts DESC")->fetchAll());
    $records = array_map('mapMedicalRecord', $pdo->query("SELECT * FROM medical_records ORDER BY created_ts DESC")->fetchAll());
    $prescriptions = array_map('mapPrescription', $pdo->query("SELECT * FROM prescriptions ORDER BY created_ts DESC")->fetchAll());
    $invoices = array_map('mapInvoice', $pdo->query("SELECT * FROM invoices ORDER BY created_ts DESC")->fetchAll());
    $expenses = array_map('mapExpense', $pdo->query("SELECT * FROM expenses ORDER BY created_ts DESC")->fetchAll());
    $services = $pdo->query("SELECT * FROM services")->fetchAll();
    $medicines = $pdo->query("SELECT * FROM medicines")->fetchAll();

    Response::json(200, [
        'settings' => $settings, 'patients' => $patients, 'appointments' => $appointments,
        'medicalRecords' => $records, 'prescriptions' => $prescriptions, 'invoices' => $invoices,
        'expenses' => $expenses, 'services' => $services, 'medicines' => $medicines,
    ]);
    exit;
}

if ($method === 'GET' && $path === '/settings') {
    Response::json(200, SettingsStore::stripPasswords(SettingsStore::getSettingsRow()));
    exit;
}

if ($method === 'PUT' && $path === '/settings') {
    Auth::requireAdmin($user);
    try {
        $saved = SettingsStore::saveSettingsRow($body);
        Response::json(200, SettingsStore::stripPasswords($saved));
    } catch (RuntimeException $e) {
        Response::json(400, ['error' => $e->getMessage()]);
    }
    exit;
}

// ------------------------------------------------------------------
// Patients
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/patients') {
    Auth::requirePermission($user, 'patients');
    require_body_valid(Validate::patient($body));
    $pdo = Database::connection();
    $id = newId('p');
    $createdAt = date('Y-m-d');
    $stmt = $pdo->prepare("INSERT INTO patients (id, name, phone, age, gender, address, blood_group, medical_history, created_at) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$id, $body['name'], $body['phone'] ?? null, $body['age'] ?? null, $body['gender'] ?? null, $body['address'] ?? null, $body['bloodGroup'] ?? null, $body['medicalHistory'] ?? null, $createdAt]);
    $row = $pdo->query("SELECT * FROM patients WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, mapPatient($row));
    exit;
}

// ------------------------------------------------------------------
// Appointments
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/appointments') {
    Auth::requirePermission($user, 'appointments');
    require_body_valid(Validate::appointment($body));
    $pdo = Database::connection();
    $id = newId('a');
    $stmt = $pdo->prepare("INSERT INTO appointments (id, patient_id, patient_name, doctor_name, date, time, status, type, notes, price) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$id, $body['patientId'] ?? null, $body['patientName'], $body['doctorName'], $body['date'], $body['time'] ?? null, $body['status'] ?? null, $body['type'] ?? null, $body['notes'] ?? null, $body['price'] ?? 0]);
    $row = $pdo->query("SELECT * FROM appointments WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, mapAppointment($row));
    exit;
}

if ($method === 'PATCH' && count($segments) === 3 && $segments[0] === 'appointments' && $segments[2] === 'status') {
    Auth::requirePermission($user, 'appointments');
    $pdo = Database::connection();
    $stmt = $pdo->prepare("UPDATE appointments SET status = ? WHERE id = ?");
    $stmt->execute([$body['status'] ?? null, $segments[1]]);
    Response::json(200, ['ok' => true]);
    exit;
}

// ------------------------------------------------------------------
// Medical records
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/medical-records') {
    Auth::requirePermission($user, 'records');
    require_body_valid(Validate::medicalRecord($body));
    $pdo = Database::connection();
    $id = newId('r');
    $stmt = $pdo->prepare("INSERT INTO medical_records (id, patient_id, patient_name, date, symptoms, diagnosis, treatment_notes, vitals, doctor_name) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$id, $body['patientId'] ?? null, $body['patientName'], $body['date'], $body['symptoms'] ?? null, $body['diagnosis'] ?? null, $body['treatmentNotes'] ?? null, json_encode($body['vitals'] ?? (object)[]), $body['doctorName'] ?? null]);
    $row = $pdo->query("SELECT * FROM medical_records WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, mapMedicalRecord($row));
    exit;
}

// ------------------------------------------------------------------
// Prescriptions (also deducts medicine stock atomically)
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/prescriptions') {
    Auth::requirePermission($user, 'prescriptions');
    require_body_valid(Validate::prescription($body));
    $pdo = Database::connection();
    $id = newId('pr');
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("INSERT INTO prescriptions (id, patient_id, patient_name, date, diagnosis, medications, tests, advice, doctor_name) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$id, $body['patientId'] ?? null, $body['patientName'], $body['date'], $body['diagnosis'] ?? null, json_encode($body['medications'] ?? []), json_encode($body['tests'] ?? []), $body['advice'] ?? null, $body['doctorName'] ?? null]);

        $counts = [];
        foreach (($body['medications'] ?? []) as $m) {
            $name = $m['name'] ?? null;
            if ($name) {
                $counts[$name] = ($counts[$name] ?? 0) + 1;
            }
        }
        foreach ($counts as $name => $count) {
            $upd = $pdo->prepare("UPDATE medicines SET stock = GREATEST(0, stock - ?) WHERE name = ?");
            $upd->execute([$count, $name]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    $row = $pdo->query("SELECT * FROM prescriptions WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, mapPrescription($row));
    exit;
}

// ------------------------------------------------------------------
// Invoices
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/invoices') {
    Auth::requirePermission($user, 'billing');
    require_body_valid(Validate::invoice($body));
    $pdo = Database::connection();
    $id = newId('inv');
    $stmt = $pdo->prepare("INSERT INTO invoices (id, patient_id, patient_name, items, total_amount, paid_amount, status, date, payment_method) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$id, $body['patientId'] ?? null, $body['patientName'], json_encode($body['items'] ?? []), $body['totalAmount'] ?? 0, $body['paidAmount'] ?? 0, $body['status'] ?? null, $body['date'], $body['paymentMethod'] ?? null]);
    $row = $pdo->query("SELECT * FROM invoices WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, mapInvoice($row));
    exit;
}

if ($method === 'PATCH' && count($segments) === 3 && $segments[0] === 'invoices' && $segments[2] === 'status') {
    Auth::requirePermission($user, 'billing');
    $errors = array_merge(
        Validate::numberField($body, 'paidAmount', 'المبلغ المدفوع', false),
    );
    require_body_valid($errors);
    $pdo = Database::connection();
    $stmt = $pdo->prepare("UPDATE invoices SET status = ?, paid_amount = ? WHERE id = ?");
    $stmt->execute([$body['status'] ?? null, $body['paidAmount'] ?? 0, $segments[1]]);
    Response::json(200, ['ok' => true]);
    exit;
}

// ------------------------------------------------------------------
// Expenses
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/expenses') {
    Auth::requirePermission($user, 'expenses');
    require_body_valid(Validate::expense($body));
    $pdo = Database::connection();
    $id = newId('exp');
    $stmt = $pdo->prepare("INSERT INTO expenses (id, title, category, amount, date, notes) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$id, $body['title'], $body['category'] ?? null, $body['amount'] ?? 0, $body['date'], $body['notes'] ?? null]);
    $row = $pdo->query("SELECT * FROM expenses WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, mapExpense($row));
    exit;
}

if ($method === 'DELETE' && count($segments) === 2 && $segments[0] === 'expenses') {
    Auth::requirePermission($user, 'expenses');
    $pdo = Database::connection();
    $pdo->prepare("DELETE FROM expenses WHERE id = ?")->execute([$segments[1]]);
    Response::json(200, ['ok' => true]);
    exit;
}

// ------------------------------------------------------------------
// Services
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/services') {
    Auth::requirePermission($user, 'services');
    require_body_valid(Validate::service($body));
    $pdo = Database::connection();
    $id = newId('s');
    $stmt = $pdo->prepare("INSERT INTO services (id, name, category, price, duration_minutes) VALUES (?,?,?,?,?)");
    $stmt->execute([$id, $body['name'], $body['category'] ?? null, $body['price'] ?? 0, $body['durationMinutes'] ?? 0]);
    $row = $pdo->query("SELECT * FROM services WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, $row);
    exit;
}

if ($method === 'DELETE' && count($segments) === 2 && $segments[0] === 'services') {
    Auth::requirePermission($user, 'services');
    $pdo = Database::connection();
    $pdo->prepare("DELETE FROM services WHERE id = ?")->execute([$segments[1]]);
    Response::json(200, ['ok' => true]);
    exit;
}

// ------------------------------------------------------------------
// Medicines
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/medicines') {
    Auth::requirePermission($user, 'medicines');
    require_body_valid(Validate::medicine($body));
    $pdo = Database::connection();
    $id = newId('m');
    $stmt = $pdo->prepare("INSERT INTO medicines (id, name, form, concentration, stock, price) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$id, $body['name'], $body['form'] ?? null, $body['concentration'] ?? null, $body['stock'] ?? 0, $body['price'] ?? 0]);
    $row = $pdo->query("SELECT * FROM medicines WHERE id = " . $pdo->quote($id))->fetch();
    Response::json(201, $row);
    exit;
}

if ($method === 'DELETE' && count($segments) === 2 && $segments[0] === 'medicines') {
    Auth::requirePermission($user, 'medicines');
    $pdo = Database::connection();
    $pdo->prepare("DELETE FROM medicines WHERE id = ?")->execute([$segments[1]]);
    Response::json(200, ['ok' => true]);
    exit;
}

// ------------------------------------------------------------------
// AI proxy (clinical assist + chat) — ported from server.ts
// ------------------------------------------------------------------
if ($method === 'POST' && $path === '/ai/clinical-assist') {
    $symptoms = $body['symptoms'] ?? '';
    if (!$symptoms) {
        Response::json(400, ['error' => 'الأعراض مطلوبة']);
        exit;
    }
    $prompt = "أنت مساعد طبي ذكي لنظام \"حكيم\" لإدارة العيادات. قدم اقتراحات تشخيصية محتملة، فحوصات مخبرية أو شعاعية مقترحة، وتوصيات علاجية أولية بناءً على المعطيات التالية:\n"
        . "العمر: " . ($body['patientAge'] ?? 'غير محدد') . "\n"
        . "الجنس: " . ($body['patientGender'] ?? 'غير محدد') . "\n"
        . "التاريخ المرضي السابق: " . ($body['medicalHistory'] ?? 'لا يوجد') . "\n"
        . "الاعراض الحالية والشكوى: {$symptoms}\n\n"
        . "قدم الإجابة باللغة العربية بأسلوب طبي مهني ومنظم (تشخيصات محتملة، فحوصات مقترحة، توصيات علاجية).";
    try {
        $result = Ai::generate($prompt, 'أنت مساعد طبي استشاري ذكي ومساعد للأطباء في عيادات حكيم الطبية.', [
            'provider' => $body['aiProvider'] ?? null, 'apiKey' => $body['aiApiKey'] ?? null, 'endpoint' => $body['aiCustomEndpoint'] ?? null,
        ]);
        Response::json(200, ['result' => $result ?: 'لم يتم توليد توصيات.']);
    } catch (Throwable $e) {
        Response::json(500, ['error' => $e->getMessage()]);
    }
    exit;
}

if ($method === 'POST' && $path === '/ai/chat') {
    $message = $body['message'] ?? '';
    if (!$message) {
        Response::json(400, ['error' => 'الرسالة مطلوبة']);
        exit;
    }
    try {
        $result = Ai::generate($message, 'أنت مساعد ذكي لإدارة عيادات "حكيم". تجيب على أسئلة إدارة العيادات، تنظيم المواعيد، وكفاءة العمل بمهنية واحترافية.', [
            'provider' => $body['aiProvider'] ?? null, 'apiKey' => $body['aiApiKey'] ?? null, 'endpoint' => $body['aiCustomEndpoint'] ?? null,
        ]);
        Response::json(200, ['text' => $result ?: 'أنا هنا لمساعدتك في إدارة عيادتك بكفاءة عالية!']);
    } catch (Throwable $e) {
        Response::json(500, ['error' => $e->getMessage()]);
    }
    exit;
}

Response::json(404, ['error' => 'المسار غير موجود']);
