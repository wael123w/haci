<?php
require_once __DIR__ . '/env.php';
require_once __DIR__ . '/Response.php';

// A minimal, dependency-free signed-token implementation (HMAC-SHA256,
// JWT-compatible structure: header.payload.signature, all base64url).
// This avoids requiring Composer/firebase-jwt on shared hosting while
// giving the same guarantees the previous Node/jsonwebtoken code had:
// the payload cannot be forged or altered without knowing JWT_SECRET.
final class Auth
{
    private const TTL_SECONDS = 7 * 24 * 60 * 60; // 7 days, matches previous "7d" expiry

    private static function secret(): string
    {
        $secret = env_get('JWT_SECRET', '');
        if (!$secret) {
            Response::json(500, ['error' => 'JWT_SECRET غير مُعرّف في .env — لا يمكن إصدار جلسات دخول بأمان.']);
            exit;
        }
        return $secret;
    }

    private static function b64url(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function b64urlDecode(string $data): string
    {
        $pad = strlen($data) % 4;
        if ($pad) {
            $data .= str_repeat('=', 4 - $pad);
        }
        return base64_decode(strtr($data, '-_', '+/'));
    }

    public static function signToken(array $userClaims): string
    {
        $header = self::b64url(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $payload = $userClaims;
        $payload['exp'] = time() + self::TTL_SECONDS;
        $payloadEncoded = self::b64url(json_encode($payload));
        $signature = self::b64url(hash_hmac('sha256', "{$header}.{$payloadEncoded}", self::secret(), true));
        return "{$header}.{$payloadEncoded}.{$signature}";
    }

    /** Returns the decoded claims array, or null if invalid/expired. */
    public static function verifyToken(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return null;
        }
        [$header, $payload, $signature] = $parts;
        $expected = self::b64url(hash_hmac('sha256', "{$header}.{$payload}", self::secret(), true));
        if (!hash_equals($expected, $signature)) {
            return null;
        }
        $claims = json_decode(self::b64urlDecode($payload), true);
        if (!is_array($claims)) {
            return null;
        }
        if (($claims['exp'] ?? 0) < time()) {
            return null;
        }
        return $claims;
    }

    public static function hashPassword(string $plain): string
    {
        return password_hash($plain, PASSWORD_BCRYPT, ['cost' => 10]);
    }

    public static function verifyPassword(string $plain, string $hash): bool
    {
        return password_verify($plain, $hash);
    }

    /** Reads Authorization: Bearer <token>, returns claims or null. */
    public static function currentUser(): ?array
    {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!$header && function_exists('apache_request_headers')) {
            $all = apache_request_headers();
            $header = $all['Authorization'] ?? $all['authorization'] ?? '';
        }
        if (!str_starts_with($header, 'Bearer ')) {
            return null;
        }
        return self::verifyToken(substr($header, 7));
    }

    /** Aborts the request with 401 if there's no valid session. Returns claims. */
    public static function requireAuth(): array
    {
        $user = self::currentUser();
        if (!$user) {
            Response::json(401, ['error' => 'غير مصرح، الرجاء تسجيل الدخول']);
            exit;
        }
        return $user;
    }

    /** Aborts with 403 unless the user is admin or has the given tab permission. */
    public static function requirePermission(array $user, string $tab): void
    {
        if (($user['role'] ?? '') === 'admin') {
            return;
        }
        if (!empty($user['permissions'][$tab])) {
            return;
        }
        Response::json(403, ['error' => 'ليست لديك صلاحية للقيام بهذا الإجراء']);
        exit;
    }

    public static function requireAdmin(array $user): void
    {
        if (($user['role'] ?? '') !== 'admin') {
            Response::json(403, ['error' => 'هذا الإجراء متاح للمسؤول (admin) فقط']);
            exit;
        }
    }
}
