<?php
require_once __DIR__ . '/env.php';

final class Database
{
    private static ?PDO $pdo = null;

    public static function connection(): PDO
    {
        if (self::$pdo !== null) {
            return self::$pdo;
        }

        $host = env_get('DB_HOST', 'localhost');
        $port = env_get('DB_PORT', '3306');
        $name = env_get('DB_NAME', '');
        $user = env_get('DB_USER', '');
        $pass = env_get('DB_PASSWORD', '');

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
        self::$pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);

        return self::$pdo;
    }

    /** Used only by the installer, which needs to test/connect with
     * credentials that haven't been written to .env yet. */
    public static function testConnection(string $host, string $port, string $name, string $user, string $pass): array
    {
        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
            new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            return [true, ''];
        } catch (PDOException $e) {
            return [false, $e->getMessage()];
        }
    }
}
