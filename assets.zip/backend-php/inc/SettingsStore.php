<?php
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Auth.php';

final class SettingsStore
{
    /** Returns the full settings object (clinic config + `users` array
     * reconstructed from the `users` table) exactly as the frontend
     * (src/types.ts ClinicSettings) expects it. Passwords are real
     * bcrypt hashes here — callers must run stripPasswords() before
     * sending this to the browser. */
    public static function getSettingsRow(): array
    {
        $pdo = Database::connection();
        $stmt = $pdo->query("SELECT data FROM settings WHERE id = 1");
        $row = $stmt->fetch();
        if (!$row) {
            throw new RuntimeException('صف الإعدادات غير موجود — يبدو أن التثبيت لم يكتمل.');
        }
        $settings = json_decode($row['data'], true) ?: [];
        $settings['users'] = self::allUsers();
        return $settings;
    }

    public static function allUsers(): array
    {
        $pdo = Database::connection();
        $rows = $pdo->query("SELECT * FROM users ORDER BY created_at ASC")->fetchAll();
        return array_map(fn($u) => self::mapUserRow($u), $rows);
    }

    private static function mapUserRow(array $u): array
    {
        return [
            'id' => $u['id'],
            'username' => $u['username'],
            'password' => $u['password_hash'], // stripped by stripPasswords() before it reaches the browser
            'name' => $u['name'],
            'role' => $u['role'],
            'specialty' => $u['specialty'],
            'permissions' => json_decode($u['permissions'] ?? '{}', true) ?: [],
        ];
    }

    public static function stripPasswords(array $settings): array
    {
        if (isset($settings['users']) && is_array($settings['users'])) {
            $settings['users'] = array_map(function ($u) {
                $u['password'] = '';
                return $u;
            }, $settings['users']);
        }
        return $settings;
    }

    public static function findUserByUsername(string $username): ?array
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE LOWER(username) = LOWER(?) LIMIT 1");
        $stmt->execute([trim($username)]);
        $row = $stmt->fetch();
        return $row ? self::mapUserRow($row) : null;
    }

    /** Saves clinic settings (everything except `users`) and syncs the
     * `users` table from the incoming `users` array:
     *  - existing ids are updated (password only rehashed if a new
     *    plaintext value was submitted)
     *  - ids not present in the current DB are inserted as new users
     *  - the UNIQUE(username) constraint on the table itself is the
     *    final backstop against duplicate accounts
     *  - ids missing from the incoming array are removed, matching the
     *    original "whole list is replaced" semantics of this screen
     *
     * Throws RuntimeException with an Arabic message on duplicate
     * usernames so the caller can turn it into a clean 400 response.
     */
    public static function saveSettingsRow(array $incoming): array
    {
        $pdo = Database::connection();
        $incomingUsers = $incoming['users'] ?? [];
        unset($incoming['users']);

        $current = self::getSettingsRow();
        $currentClinicFields = $current;
        unset($currentClinicFields['users']);
        $merged = array_merge($currentClinicFields, $incoming);

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("UPDATE settings SET data = ? WHERE id = 1");
            $stmt->execute([json_encode($merged, JSON_UNESCAPED_UNICODE)]);

            $existingById = [];
            foreach ($pdo->query("SELECT id, password_hash FROM users")->fetchAll() as $row) {
                $existingById[$row['id']] = $row['password_hash'];
            }

            $keepIds = [];
            foreach ($incomingUsers as $u) {
                $id = $u['id'] ?? ('u-' . bin2hex(random_bytes(6)));
                $keepIds[] = $id;
                $username = trim((string)($u['username'] ?? ''));
                if ($username === '') {
                    throw new RuntimeException('اسم المستخدم مطلوب لكل حساب');
                }

                $plain = trim((string)($u['password'] ?? ''));
                if ($plain !== '') {
                    $hash = Auth::hashPassword($plain);
                } elseif (isset($existingById[$id])) {
                    $hash = $existingById[$id];
                } else {
                    throw new RuntimeException("كلمة مرور مطلوبة للحساب الجديد \"{$username}\"");
                }

                $permissions = json_encode($u['permissions'] ?? [], JSON_UNESCAPED_UNICODE);

                if (isset($existingById[$id])) {
                    $upd = $pdo->prepare(
                        "UPDATE users SET username = ?, password_hash = ?, name = ?, role = ?, specialty = ?, permissions = ? WHERE id = ?"
                    );
                    $upd->execute([$username, $hash, $u['name'] ?? '', $u['role'] ?? 'receptionist', $u['specialty'] ?? '', $permissions, $id]);
                } else {
                    $ins = $pdo->prepare(
                        "INSERT INTO users (id, username, password_hash, name, role, specialty, permissions) VALUES (?, ?, ?, ?, ?, ?, ?)"
                    );
                    $ins->execute([$id, $username, $hash, $u['name'] ?? '', $u['role'] ?? 'receptionist', $u['specialty'] ?? '', $permissions]);
                }
            }

            if (!empty($keepIds)) {
                $placeholders = implode(',', array_fill(0, count($keepIds), '?'));
                $del = $pdo->prepare("DELETE FROM users WHERE id NOT IN ({$placeholders})");
                $del->execute($keepIds);
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            if (str_contains($e->getMessage(), 'uniq_username') || str_contains($e->getMessage(), 'Duplicate entry')) {
                throw new RuntimeException('اسم المستخدم مستخدم بالفعل — الرجاء اختيار اسم آخر');
            }
            throw $e;
        }

        return self::getSettingsRow();
    }
}
