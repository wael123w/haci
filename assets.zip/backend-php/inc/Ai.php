<?php
require_once __DIR__ . '/env.php';

final class Ai
{
    /** Calls whichever provider the clinic configured in Settings > AI
     * (falling back to the server's own GEMINI_API_KEY for Gemini),
     * returns the plain text reply. Throws RuntimeException on failure. */
    public static function generate(string $prompt, string $systemInstruction, array $config): string
    {
        $provider = $config['provider'] ?? 'gemini';

        if ($provider === 'gemini') {
            $apiKey = $config['apiKey'] ?? env_get('GEMINI_API_KEY', '');
            if (!$apiKey) {
                throw new RuntimeException('لا يوجد مفتاح Gemini API مُعد. أضِفه في الإعدادات > الذكاء الاصطناعي.');
            }
            $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . urlencode($apiKey);
            $payload = [
                'contents' => [['parts' => [['text' => $prompt]]]],
                'systemInstruction' => ['parts' => [['text' => $systemInstruction]]],
            ];
            $data = self::post($url, $payload, []);
            return $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        }

        if ($provider === 'openai') {
            $apiKey = $config['apiKey'] ?? '';
            if (!$apiKey) {
                throw new RuntimeException('مفتاح OpenAI API مفقود. أضِفه في الإعدادات > الذكاء الاصطناعي.');
            }
            $data = self::post('https://api.openai.com/v1/chat/completions', [
                'model' => 'gpt-4o-mini',
                'messages' => [
                    ['role' => 'system', 'content' => $systemInstruction],
                    ['role' => 'user', 'content' => $prompt],
                ],
            ], ["Authorization: Bearer {$apiKey}"]);
            return $data['choices'][0]['message']['content'] ?? '';
        }

        if ($provider === 'anthropic') {
            $apiKey = $config['apiKey'] ?? '';
            if (!$apiKey) {
                throw new RuntimeException('مفتاح Anthropic API مفقود. أضِفه في الإعدادات > الذكاء الاصطناعي.');
            }
            $data = self::post('https://api.anthropic.com/v1/messages', [
                'model' => 'claude-3-5-haiku-latest',
                'max_tokens' => 1024,
                'system' => $systemInstruction,
                'messages' => [['role' => 'user', 'content' => $prompt]],
            ], ["x-api-key: {$apiKey}", "anthropic-version: 2023-06-01"]);
            return $data['content'][0]['text'] ?? '';
        }

        // "custom": assumes an OpenAI-compatible chat completions endpoint.
        $endpoint = $config['endpoint'] ?? '';
        if (!$endpoint) {
            throw new RuntimeException('رابط نقطة الذكاء الاصطناعي المخصصة مفقود.');
        }
        $headers = [];
        if (!empty($config['apiKey'])) {
            $headers[] = "Authorization: Bearer {$config['apiKey']}";
        }
        $data = self::post($endpoint, [
            'messages' => [
                ['role' => 'system', 'content' => $systemInstruction],
                ['role' => 'user', 'content' => $prompt],
            ],
        ], $headers);
        return $data['choices'][0]['message']['content'] ?? ($data['text'] ?? '');
    }

    private static function post(string $url, array $payload, array $headers): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json'], $headers),
            CURLOPT_TIMEOUT => 30,
        ]);
        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            throw new RuntimeException("تعذر الاتصال بخدمة الذكاء الاصطناعي: {$error}");
        }
        if ($status >= 400) {
            throw new RuntimeException("طلب الذكاء الاصطناعي فشل (HTTP {$status})");
        }
        $data = json_decode($response, true);
        return is_array($data) ? $data : [];
    }
}
