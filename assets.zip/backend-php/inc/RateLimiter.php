<?php
require_once __DIR__ . '/Database.php';

final class RateLimiter
{
    private const MAX_ATTEMPTS = 5;
    private const WINDOW_MINUTES = 15;

    public static function clientIp(): string
    {
        return $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    /** Returns [blocked(bool), secondsRemaining(int)] for this IP+username pair. */
    public static function check(string $ip, string $username): array
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) AS cnt, MIN(attempted_at) AS first_at
             FROM login_attempts
             WHERE ip_address = ? AND username = ? AND success = 0
               AND attempted_at > (NOW() - INTERVAL ? MINUTE)"
        );
        $stmt->execute([$ip, $username, self::WINDOW_MINUTES]);
        $row = $stmt->fetch();
        $count = (int)($row['cnt'] ?? 0);
        if ($count < self::MAX_ATTEMPTS) {
            return [false, 0];
        }
        return [true, self::WINDOW_MINUTES * 60];
    }

    public static function recordAttempt(string $ip, string $username, bool $success): void
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare(
            "INSERT INTO login_attempts (ip_address, username, success) VALUES (?, ?, ?)"
        );
        $stmt->execute([$ip, $username, $success ? 1 : 0]);

        // Keep the table small: opportunistically prune old rows.
        if (random_int(1, 20) === 1) {
            $pdo->exec("DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 1 DAY)");
        }
    }
}
