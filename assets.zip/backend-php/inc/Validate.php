<?php
require_once __DIR__ . '/Response.php';

// Small validation toolkit. Each `rules(...)` call returns a list of Arabic
// error strings (empty = valid). Handlers call Validate::fail() to send a
// 400 with the first error and stop, mirroring the zod behavior requested
// in the brief: reject bad input with a clear message instead of a 500 or
// silently accepting garbage.
final class Validate
{
    public static function fail(array $errors): void
    {
        Response::json(400, [
            'error' => $errors[0],
            'errors' => $errors,
        ]);
        exit;
    }

    public static function requiredString(array $body, string $field, string $label, int $max = 255): array
    {
        $v = $body[$field] ?? null;
        if (!is_string($v) || trim($v) === '') {
            return ["حقل \"{$label}\" مطلوب"];
        }
        if (mb_strlen($v) > $max) {
            return ["حقل \"{$label}\" أطول من الحد المسموح ({$max} حرف)"];
        }
        return [];
    }

    public static function optionalString(array $body, string $field, string $label, int $max = 2000): array
    {
        $v = $body[$field] ?? null;
        if ($v === null || $v === '') {
            return [];
        }
        if (!is_string($v)) {
            return ["حقل \"{$label}\" يجب أن يكون نصاً"];
        }
        if (mb_strlen($v) > $max) {
            return ["حقل \"{$label}\" أطول من الحد المسموح ({$max} حرف)"];
        }
        return [];
    }

    /** Non-negative integer, required or optional depending on $required.
     * Rejects non-numeric values, decimals, and negatives with a clear
     * Arabic message instead of silently coercing them (e.g. age="abc"
     * or age=-5 on POST /api/patients). */
    public static function intField(array $body, string $field, string $label, bool $required = false, ?int $min = 0, ?int $max = null): array
    {
        $v = $body[$field] ?? null;
        if ($v === null || $v === '') {
            return $required ? ["حقل \"{$label}\" مطلوب"] : [];
        }
        if (is_bool($v) || is_array($v) || !is_numeric($v) || (is_string($v) && !preg_match('/^-?\d+$/', trim($v)))) {
            return ["حقل \"{$label}\" يجب أن يكون رقماً صحيحاً"];
        }
        $num = (int)$v;
        if ($min !== null && $num < $min) {
            return ["حقل \"{$label}\" لا يمكن أن يكون أقل من {$min}"];
        }
        if ($max !== null && $num > $max) {
            return ["حقل \"{$label}\" لا يمكن أن يكون أكبر من {$max}"];
        }
        return [];
    }

    /** Non-negative decimal (money/price), required or optional. */
    public static function numberField(array $body, string $field, string $label, bool $required = false, ?float $min = 0): array
    {
        $v = $body[$field] ?? null;
        if ($v === null || $v === '') {
            return $required ? ["حقل \"{$label}\" مطلوب"] : [];
        }
        if (!is_numeric($v)) {
            return ["حقل \"{$label}\" يجب أن يكون رقماً"];
        }
        if ($min !== null && (float)$v < $min) {
            return ["حقل \"{$label}\" لا يمكن أن يكون قيمة سالبة"];
        }
        return [];
    }

    public static function enumField(array $body, string $field, string $label, array $allowed, bool $required = false): array
    {
        $v = $body[$field] ?? null;
        if ($v === null || $v === '') {
            return $required ? ["حقل \"{$label}\" مطلوب"] : [];
        }
        if (!in_array($v, $allowed, true)) {
            return ["قيمة \"{$label}\" غير صالحة"];
        }
        return [];
    }

    // ------------------------------------------------------------------
    // Per-endpoint schemas
    // ------------------------------------------------------------------

    public static function patient(array $b): array
    {
        return array_merge(
            self::requiredString($b, 'name', 'الاسم', 255),
            self::optionalString($b, 'phone', 'الهاتف', 50),
            self::intField($b, 'age', 'العمر', false, 0, 150),
            self::optionalString($b, 'gender', 'الجنس', 20),
            self::optionalString($b, 'address', 'العنوان', 255),
            self::optionalString($b, 'bloodGroup', 'فصيلة الدم', 10),
            self::optionalString($b, 'medicalHistory', 'التاريخ المرضي', 5000),
        );
    }

    public static function appointment(array $b): array
    {
        return array_merge(
            self::optionalString($b, 'patientId', 'رقم المريض', 64),
            self::requiredString($b, 'patientName', 'اسم المريض', 255),
            self::requiredString($b, 'doctorName', 'اسم الطبيب', 255),
            self::requiredString($b, 'date', 'التاريخ', 20),
            self::optionalString($b, 'time', 'الوقت', 10),
            self::optionalString($b, 'status', 'الحالة', 30),
            self::optionalString($b, 'type', 'النوع', 100),
            self::optionalString($b, 'notes', 'ملاحظات', 2000),
            self::numberField($b, 'price', 'السعر', false),
        );
    }

    public static function medicalRecord(array $b): array
    {
        return array_merge(
            self::optionalString($b, 'patientId', 'رقم المريض', 64),
            self::requiredString($b, 'patientName', 'اسم المريض', 255),
            self::requiredString($b, 'date', 'التاريخ', 20),
            self::optionalString($b, 'symptoms', 'الأعراض', 5000),
            self::optionalString($b, 'diagnosis', 'التشخيص', 5000),
            self::optionalString($b, 'treatmentNotes', 'ملاحظات العلاج', 5000),
            self::optionalString($b, 'doctorName', 'اسم الطبيب', 255),
        );
    }

    public static function prescription(array $b): array
    {
        $errors = array_merge(
            self::optionalString($b, 'patientId', 'رقم المريض', 64),
            self::requiredString($b, 'patientName', 'اسم المريض', 255),
            self::requiredString($b, 'date', 'التاريخ', 20),
            self::optionalString($b, 'diagnosis', 'التشخيص', 5000),
            self::optionalString($b, 'advice', 'التوصيات', 5000),
            self::optionalString($b, 'doctorName', 'اسم الطبيب', 255),
        );
        if (isset($b['medications']) && !is_array($b['medications'])) {
            $errors[] = 'قائمة الأدوية غير صالحة';
        }
        if (isset($b['tests']) && !is_array($b['tests'])) {
            $errors[] = 'قائمة الفحوصات غير صالحة';
        }
        return $errors;
    }

    public static function invoice(array $b): array
    {
        $errors = array_merge(
            self::optionalString($b, 'patientId', 'رقم المريض', 64),
            self::requiredString($b, 'patientName', 'اسم المريض', 255),
            self::requiredString($b, 'date', 'التاريخ', 20),
            self::numberField($b, 'totalAmount', 'إجمالي المبلغ', false),
            self::numberField($b, 'paidAmount', 'المبلغ المدفوع', false),
            self::optionalString($b, 'status', 'الحالة', 30),
            self::optionalString($b, 'paymentMethod', 'طريقة الدفع', 50),
        );
        if (isset($b['items']) && !is_array($b['items'])) {
            $errors[] = 'قائمة العناصر غير صالحة';
        }
        return $errors;
    }

    public static function expense(array $b): array
    {
        return array_merge(
            self::requiredString($b, 'title', 'العنوان', 255),
            self::optionalString($b, 'category', 'التصنيف', 100),
            self::numberField($b, 'amount', 'المبلغ', false),
            self::requiredString($b, 'date', 'التاريخ', 20),
            self::optionalString($b, 'notes', 'ملاحظات', 2000),
        );
    }

    public static function service(array $b): array
    {
        return array_merge(
            self::requiredString($b, 'name', 'الاسم', 255),
            self::optionalString($b, 'category', 'التصنيف', 100),
            self::numberField($b, 'price', 'السعر', false),
            self::intField($b, 'durationMinutes', 'المدة بالدقائق', false, 0, 1440),
        );
    }

    public static function medicine(array $b): array
    {
        return array_merge(
            self::requiredString($b, 'name', 'الاسم', 255),
            self::optionalString($b, 'form', 'الشكل الصيدلاني', 100),
            self::optionalString($b, 'concentration', 'التركيز', 100),
            self::intField($b, 'stock', 'المخزون', false, 0),
            self::numberField($b, 'price', 'السعر', false),
        );
    }

    public static function login(array $b): array
    {
        return array_merge(
            self::requiredString($b, 'username', 'اسم المستخدم', 100),
            self::requiredString($b, 'password', 'كلمة المرور', 255),
        );
    }
}
