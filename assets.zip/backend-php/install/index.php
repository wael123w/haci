<?php
declare(strict_types=1);
session_start();

$rootDir = dirname(__DIR__);
$lockFile = $rootDir . '/install.lock';
$envFile = $rootDir . '/.env';
$schemaFile = $rootDir . '/db/schema.sql';

// Once installed, /install is dead — always bounce to the app/login page.
if (is_file($lockFile)) {
    header('Location: /');
    exit;
}

require_once $rootDir . '/inc/Database.php';
require_once $rootDir . '/inc/Auth.php';

$action = $_GET['action'] ?? $_POST['action'] ?? null;
$step = (int)($_SESSION['install_step'] ?? 1);

// ---------------------------------------------------------------------
// AJAX-style actions (all return JSON, called by the page's own JS)
// ---------------------------------------------------------------------
if ($action === 'test_db') {
    header('Content-Type: application/json; charset=utf-8');
    $host = trim($_POST['db_host'] ?? '');
    $port = trim($_POST['db_port'] ?? '3306');
    $name = trim($_POST['db_name'] ?? '');
    $user = trim($_POST['db_user'] ?? '');
    $pass = (string)($_POST['db_pass'] ?? '');

    if ($host === '' || $name === '' || $user === '') {
        echo json_encode(['ok' => false, 'message' => 'الرجاء تعبئة جميع حقول الاتصال بقاعدة البيانات']);
        exit;
    }
    [$ok, $error] = Database::testConnection($host, $port, $name, $user, $pass);
    if ($ok) {
        $_SESSION['db'] = compact('host', 'port', 'name', 'user', 'pass');
        $_SESSION['install_step'] = 3;
    }
    echo json_encode(['ok' => $ok, 'message' => $ok ? 'تم الاتصال بنجاح ✅' : "تعذر الاتصال: {$error}"]);
    exit;
}

function applySchema(PDO $pdo, string $schemaFile): void
{
    $sql = file_get_contents($schemaFile);
    if ($sql === false) {
        throw new RuntimeException('تعذر قراءة ملف schema.sql');
    }
    // Simple, safe-for-this-file statement split (no stored procedures
    // or triggers in this schema, so splitting on ";" is reliable).
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) {
        if ($statement === '' || str_starts_with($statement, '--')) {
            continue;
        }
        $pdo->exec($statement);
    }
}

function tableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
    $stmt->execute([$table]);
    return (bool)$stmt->fetch();
}

if ($action === 'run_schema') {
    header('Content-Type: application/json; charset=utf-8');
    $db = $_SESSION['db'] ?? null;
    if (!$db) {
        echo json_encode(['ok' => false, 'message' => 'الرجاء اختبار الاتصال بقاعدة البيانات أولاً']);
        exit;
    }
    try {
        $dsn = "mysql:host={$db['host']};port={$db['port']};dbname={$db['name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $db['user'], $db['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        applySchema($pdo, $schemaFile);
        if (!tableExists($pdo, 'settings') || !tableExists($pdo, 'users')) {
            throw new RuntimeException('تم تنفيذ schema.sql لكن الجداول الأساسية (settings/users) غير موجودة — تحقق من صلاحيات المستخدم على قاعدة البيانات.');
        }
        $_SESSION['install_step'] = 4;
        echo json_encode(['ok' => true, 'message' => 'تم إنشاء جداول قاعدة البيانات بنجاح ✅']);
    } catch (Throwable $e) {
        echo json_encode(['ok' => false, 'message' => 'فشل تنفيذ schema.sql: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'finish') {
    header('Content-Type: application/json; charset=utf-8');
    $db = $_SESSION['db'] ?? null;
    if (!$db) {
        echo json_encode(['ok' => false, 'message' => 'انتهت الجلسة، الرجاء البدء من جديد']);
        exit;
    }
    $clinicName = trim($_POST['clinic_name'] ?? '');
    $adminUser = trim($_POST['admin_username'] ?? '');
    $adminPass = (string)($_POST['admin_password'] ?? '');
    $adminName = trim($_POST['admin_name'] ?? '') ?: 'مسؤول النظام';

    if ($clinicName === '' || $adminUser === '' || strlen($adminPass) < 8) {
        echo json_encode(['ok' => false, 'message' => 'الرجاء تعبئة كل الحقول — يجب أن تكون كلمة المرور 8 أحرف على الأقل']);
        exit;
    }

    try {
        $dsn = "mysql:host={$db['host']};port={$db['port']};dbname={$db['name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $db['user'], $db['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

        // Self-heal: if a session hiccup meant step 3 never actually ran
        // (or ran against a different db before the user changed fields),
        // apply the schema now instead of failing on a missing table.
        if (!tableExists($pdo, 'settings') || !tableExists($pdo, 'users')) {
            applySchema($pdo, $schemaFile);
        }
        if (!tableExists($pdo, 'settings') || !tableExists($pdo, 'users')) {
            throw new RuntimeException('تعذر إنشاء الجداول الأساسية. تحقق من صلاحيات مستخدم قاعدة البيانات (يحتاج CREATE TABLE).');
        }

        $existing = $pdo->query("SELECT id FROM settings WHERE id = 1")->fetch();
        if (!$existing) {
            $settingsData = [
                'clinicName' => $clinicName, 'doctorName' => '', 'specialty' => '', 'phone' => '',
                'email' => '', 'address' => '', 'workingHours' => '', 'currency' => 'ر.س',
                'consultationFee' => 100, 'supportUrl' => '', 'language' => 'ar',
                'clinicLogo' => '', 'clinicImage' => '', 'loginBackground' => '', 'siteFavicon' => '',
                'departments' => [], 'doctors' => [], 'aiProvider' => 'gemini', 'aiApiKey' => '',
                'aiCustomEndpoint' => '', 'customLanguages' => [], 'darkMode' => false,
            ];
            $pdo->prepare("INSERT INTO settings (id, data) VALUES (1, ?)")->execute([json_encode($settingsData, JSON_UNESCAPED_UNICODE)]);
        }

        $adminExists = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $adminExists->execute([$adminUser]);
        if (!$adminExists->fetch()) {
            $hash = Auth::hashPassword($adminPass);
            $permissions = json_encode(['dashboard' => true, 'patients' => true, 'appointments' => true, 'records' => true, 'prescriptions' => true, 'billing' => true, 'expenses' => true, 'services' => true, 'medicines' => true, 'settings' => true]);
            $pdo->prepare("INSERT INTO users (id, username, password_hash, name, role, permissions) VALUES (?,?,?,?,?,?)")
                ->execute(['u-' . bin2hex(random_bytes(6)), $adminUser, $hash, $adminName, 'admin', $permissions]);
        }

        $jwtSecret = bin2hex(random_bytes(48));
        $envValues = [
            'DB_HOST' => $db['host'], 'DB_PORT' => $db['port'], 'DB_NAME' => $db['name'],
            'DB_USER' => $db['user'], 'DB_PASSWORD' => $db['pass'], 'JWT_SECRET' => $jwtSecret,
            'GEMINI_API_KEY' => '',
        ];
        require_once $rootDir . '/inc/env.php';
        if (!env_write($envFile, $envValues)) {
            throw new RuntimeException('تعذرت الكتابة إلى ملف .env — تحقق من صلاحيات الكتابة على المجلد الجذر.');
        }
        if (file_put_contents($lockFile, date('c')) === false) {
            throw new RuntimeException('تعذر إنشاء install.lock — تحقق من صلاحيات الكتابة على المجلد الجذر.');
        }

        unset($_SESSION['db'], $_SESSION['install_step']);
        echo json_encode(['ok' => true, 'message' => 'اكتمل التثبيت بنجاح ✅']);
    } catch (Throwable $e) {
        echo json_encode(['ok' => false, 'message' => 'فشل التثبيت: ' . $e->getMessage()]);
    }
    exit;
}

// ---------------------------------------------------------------------
// Requirements check (used to render step 1)
// ---------------------------------------------------------------------
function checkRequirements(string $rootDir): array
{
    $phpOk = version_compare(PHP_VERSION, '8.1.0', '>=');
    $checks = [
        ['label' => 'إصدار PHP 8.1 أو أحدث (الحالي: ' . PHP_VERSION . ')', 'ok' => $phpOk],
        ['label' => 'امتداد PDO MySQL (pdo_mysql)', 'ok' => extension_loaded('pdo_mysql')],
        ['label' => 'امتداد JSON', 'ok' => extension_loaded('json')],
        ['label' => 'امتداد mbstring (دعم النصوص العربية)', 'ok' => extension_loaded('mbstring')],
        ['label' => 'امتداد OpenSSL / hash (لتشفير كلمات المرور والجلسات)', 'ok' => extension_loaded('hash')],
        ['label' => 'إمكانية الكتابة داخل المجلد الجذر (لإنشاء .env)', 'ok' => is_writable($rootDir)],
    ];
    return $checks;
}

$checks = checkRequirements($rootDir);
$allOk = !in_array(false, array_column($checks, 'ok'), true);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>معالج تثبيت نظام حكيم لإدارة العيادات</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, "Segoe UI", Tahoma, Arial, sans-serif; background: #f4f6f8; margin: 0; color: #1f2937; }
  .wrap { max-width: 640px; margin: 0 auto; padding: 32px 16px 80px; }
  h1 { font-size: 22px; text-align: center; margin-bottom: 4px; }
  .sub { text-align: center; color: #6b7280; margin-bottom: 28px; font-size: 14px; }
  .steps { display: flex; justify-content: space-between; margin-bottom: 24px; font-size: 12px; color: #9ca3af; }
  .steps span.active { color: #2563eb; font-weight: bold; }
  .card { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.08); margin-bottom: 16px; }
  .check-row { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #f1f1f1; font-size: 14px; }
  .check-row:last-child { border-bottom: none; }
  .ok { color: #16a34a; } .bad { color: #dc2626; }
  label { display: block; font-size: 13px; margin: 12px 0 4px; color: #374151; }
  input { width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; }
  button { cursor: pointer; border: none; border-radius: 10px; padding: 12px 18px; font-size: 15px; font-weight: 600; width: 100%; margin-top: 18px; }
  .btn-primary { background: #2563eb; color: #fff; }
  .btn-primary:disabled { background: #93c5fd; cursor: not-allowed; }
  .msg { margin-top: 12px; font-size: 14px; padding: 10px 12px; border-radius: 8px; display: none; }
  .msg.success { background: #dcfce7; color: #166534; display: block; }
  .msg.error { background: #fee2e2; color: #991b1b; display: block; }
  .hint { font-size: 12px; color: #9ca3af; margin-top: 6px; }
</style>
</head>
<body>
<div class="wrap">
  <h1>🩺 معالج تثبيت نظام حكيم</h1>
  <div class="sub">جهّز نسختك بالكامل من المتصفح — لا حاجة لـ Terminal أو phpMyAdmin</div>

  <div class="steps">
    <span class="<?= $step >= 1 ? 'active' : '' ?>">1. متطلبات السيرفر</span>
    <span class="<?= $step >= 2 ? 'active' : '' ?>">2. قاعدة البيانات</span>
    <span class="<?= $step >= 3 ? 'active' : '' ?>">3. الجداول</span>
    <span class="<?= $step >= 4 ? 'active' : '' ?>">4. حساب المسؤول</span>
  </div>

  <!-- STEP 1 -->
  <div class="card" id="step1" style="<?= $step === 1 ? '' : 'display:none' ?>">
    <h3>فحص متطلبات السيرفر</h3>
    <?php foreach ($checks as $c): ?>
      <div class="check-row">
        <span class="<?= $c['ok'] ? 'ok' : 'bad' ?>"><?= $c['ok'] ? '✅' : '❌' ?></span>
        <span><?= htmlspecialchars($c['label']) ?></span>
      </div>
    <?php endforeach; ?>
    <button class="btn-primary" <?= $allOk ? '' : 'disabled' ?> onclick="goStep(2)">
      <?= $allOk ? 'متابعة →' : 'أصلح المشاكل أعلاه أولاً' ?>
    </button>
  </div>

  <!-- STEP 2 -->
  <div class="card" id="step2" style="<?= $step === 2 ? '' : 'display:none' ?>">
    <h3>الاتصال بقاعدة البيانات</h3>
    <div class="hint">أنشئ قاعدة بيانات MySQL فارغة من لوحة تحكم الاستضافة (cPanel &gt; MySQL Databases) ثم أدخل بياناتها هنا.</div>
    <label>عنوان السيرفر (Host)</label>
    <input id="db_host" value="localhost">
    <label>المنفذ (Port)</label>
    <input id="db_port" value="3306">
    <label>اسم قاعدة البيانات</label>
    <input id="db_name" placeholder="cpaneluser_hakeem">
    <label>اسم مستخدم قاعدة البيانات</label>
    <input id="db_user" placeholder="cpaneluser_hakeemuser">
    <label>كلمة المرور</label>
    <input id="db_pass" type="password">
    <button class="btn-primary" onclick="testDb()">اختبار الاتصال ومتابعة →</button>
    <div class="msg" id="msg2"></div>
  </div>

  <!-- STEP 3 -->
  <div class="card" id="step3" style="<?= $step === 3 ? '' : 'display:none' ?>">
    <h3>إنشاء جداول قاعدة البيانات</h3>
    <div class="hint">سيتم الآن تنفيذ db/schema.sql تلقائياً على قاعدة البيانات التي اخترتها — لا حاجة لفتح phpMyAdmin.</div>
    <button class="btn-primary" onclick="runSchema()">تنفيذ الآن →</button>
    <div class="msg" id="msg3"></div>
  </div>

  <!-- STEP 4 -->
  <div class="card" id="step4" style="<?= $step === 4 ? '' : 'display:none' ?>">
    <h3>إنشاء أول حساب مسؤول (Admin)</h3>
    <label>اسم العيادة</label>
    <input id="clinic_name" placeholder="عيادتي">
    <label>اسم المسؤول (اختياري)</label>
    <input id="admin_name" placeholder="مسؤول النظام">
    <label>اسم المستخدم</label>
    <input id="admin_username" placeholder="admin">
    <label>كلمة المرور (8 أحرف على الأقل)</label>
    <input id="admin_password" type="password">
    <button class="btn-primary" onclick="finishInstall()">إنهاء التثبيت 🎉</button>
    <div class="msg" id="msg4"></div>
  </div>

</div>
<script>
function showStep(n) {
  for (let i = 1; i <= 4; i++) document.getElementById('step' + i).style.display = (i === n) ? '' : 'none';
}
function goStep(n) { showStep(n); }

async function post(action, data) {
  const body = new URLSearchParams({ action, ...data });
  const res = await fetch('index.php', { method: 'POST', body });
  return res.json();
}

async function testDb() {
  const data = {
    db_host: document.getElementById('db_host').value,
    db_port: document.getElementById('db_port').value,
    db_name: document.getElementById('db_name').value,
    db_user: document.getElementById('db_user').value,
    db_pass: document.getElementById('db_pass').value,
  };
  const msg = document.getElementById('msg2');
  msg.className = 'msg'; msg.textContent = 'جارٍ الاختبار...'; msg.style.display = 'block';
  const result = await post('test_db', data);
  msg.textContent = result.message;
  msg.className = 'msg ' + (result.ok ? 'success' : 'error');
  if (result.ok) setTimeout(() => showStep(3), 600);
}

async function runSchema() {
  const msg = document.getElementById('msg3');
  msg.className = 'msg'; msg.textContent = 'جارٍ إنشاء الجداول...'; msg.style.display = 'block';
  const result = await post('run_schema', {});
  msg.textContent = result.message;
  msg.className = 'msg ' + (result.ok ? 'success' : 'error');
  if (result.ok) setTimeout(() => showStep(4), 600);
}

async function finishInstall() {
  const data = {
    clinic_name: document.getElementById('clinic_name').value,
    admin_name: document.getElementById('admin_name').value,
    admin_username: document.getElementById('admin_username').value,
    admin_password: document.getElementById('admin_password').value,
  };
  const msg = document.getElementById('msg4');
  msg.className = 'msg'; msg.textContent = 'جارٍ الإنهاء...'; msg.style.display = 'block';
  const result = await post('finish', data);
  msg.textContent = result.message;
  msg.className = 'msg ' + (result.ok ? 'success' : 'error');
  if (result.ok) {
    msg.textContent += ' — سيتم تحويلك لصفحة الدخول خلال لحظات...';
    setTimeout(() => window.location.href = '/', 2000);
  }
}
</script>
</body>
</html>
