import React, { useState } from 'react';
import { 
  Bell, 
  Search, 
  Sparkles, 
  UserCheck, 
  CalendarPlus, 
  Bot, 
  X, 
  Loader2, 
  Send,
  Menu,
  LogOut,
  Shield,
  Globe
} from 'lucide-react';
import { ClinicSettings, Patient } from '../types';
import { useTranslation } from '../utils/i18n';

interface HeaderProps {
  settings: ClinicSettings;
  onUpdateSettings?: (settings: ClinicSettings) => void;
  onOpenNewAppointment: () => void;
  onOpenNewPatient: () => void;
  patients: Patient[];
  onToggleSidebar?: () => void;
  currentUser?: { name: string; role: 'doctor' | 'receptionist' | 'admin'; specialty: string };
  onLogout?: () => void;
}

export function Header({ settings, onUpdateSettings, onOpenNewAppointment, onOpenNewPatient, patients, onToggleSidebar, currentUser, onLogout }: HeaderProps) {
  const { t, currentLang } = useTranslation(settings);

  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([
    { 
      sender: 'ai', 
      text: currentLang === 'en' 
        ? `Welcome Dr. ${settings.doctorName} to Hakeem Clinic Management System. How can I assist you with your medical or administrative tasks today?`
        : `أهلاً بك يا ${settings.doctorName} في نظام حكيم لإدارة العيادات. كيف يمكنني مساعدتك في مهام اليوم الطبية أو الإدارية؟` 
    }
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput.trim();
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setChatInput('');
    setIsAiLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          aiProvider: settings.aiProvider,
          aiApiKey: settings.aiApiKey,
          aiCustomEndpoint: settings.aiCustomEndpoint,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setMessages(prev => [...prev, { sender: 'ai', text: data.text }]);
    } catch (err: any) {
      setMessages(prev => [...prev, { sender: 'ai', text: t('aiConnectionError') }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <>
      <header className={`h-20 ${settings?.darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'} border-b px-4 sm:px-8 flex items-center justify-between sticky top-0 z-30 shadow-xs`}>
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className={`md:hidden p-2.5 rounded-xl ${settings?.darkMode ? 'bg-stone-800 text-stone-200 hover:bg-stone-700' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'} transition`}
              aria-label="القائمة الجانبية"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}
          <div className={`flex items-center gap-3 ${settings?.darkMode ? 'bg-stone-800 border-stone-700 text-stone-100' : 'bg-stone-50 border-stone-200/80 text-stone-900'} border px-3 sm:px-4 py-2 rounded-2xl`}>
            <div className="w-9 h-9 rounded-xl bg-teal-900 text-teal-200 flex items-center justify-center font-bold text-sm shrink-0">
              {settings.doctorName.replace('د. ', '').charAt(0)}
            </div>
            <div className="hidden sm:block">
              <div className={`text-sm font-bold ${settings?.darkMode ? 'text-stone-100' : 'text-stone-900'}`}>{settings.doctorName}</div>
              <div className={`text-xs ${settings?.darkMode ? 'text-stone-400' : 'text-stone-500'} font-medium`}>{t('attendingDoctor')} - {settings.specialty}</div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => setIsAiModalOpen(true)}
            className="flex items-center gap-2 bg-gradient-to-r from-teal-700 to-emerald-700 text-white px-3 sm:px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold hover:opacity-95 transition shadow-sm shadow-teal-700/20"
          >
            <Bot className="w-4 h-4 text-teal-200" />
            <span className="hidden sm:inline">{t('aiAssistant')}</span>
            <span className="sm:hidden">{currentLang === 'en' ? 'AI Assistant' : 'الذكاء الاصطناعي'}</span>
            <Sparkles className="w-3.5 h-3.5 text-amber-300 hidden md:inline" />
          </button>

          <button
            onClick={onOpenNewAppointment}
            className={`hidden lg:flex items-center gap-2 ${settings?.darkMode ? 'bg-stone-100 text-stone-900 hover:bg-white' : 'bg-stone-900 text-white hover:bg-stone-800'} px-4 py-2.5 rounded-xl text-sm font-semibold transition shadow-sm`}
          >
            <CalendarPlus className="w-4 h-4 text-teal-500" />
            <span>{t('newAppointment')}</span>
          </button>

          <button
            onClick={onOpenNewPatient}
            className={`hidden lg:flex items-center gap-2 ${settings?.darkMode ? 'bg-stone-800 text-stone-200 hover:bg-stone-700 border-stone-700' : 'bg-stone-100 text-stone-800 hover:bg-stone-200 border-stone-200'} px-4 py-2.5 rounded-xl text-sm font-semibold transition border`}
          >
            <UserCheck className="w-4 h-4 text-teal-400" />
            <span>{t('registerPatient')}</span>
          </button>

          {onLogout && (
            <button
              onClick={onLogout}
              title={t('logout')}
              className={`flex items-center gap-1.5 ${settings?.darkMode ? 'bg-rose-950/80 text-rose-300 hover:bg-rose-900 border-rose-900' : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border-rose-200'} px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition border`}
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">{currentLang === 'en' ? 'Logout' : 'خروج'}</span>
            </button>
          )}

          <button
            onClick={() => {
              if (onUpdateSettings) {
                onUpdateSettings({
                  ...settings,
                  language: currentLang === 'ar' ? 'en' : 'ar'
                });
              }
            }}
            className={`flex items-center gap-1.5 ${settings?.darkMode ? 'bg-teal-950 hover:bg-teal-900 text-teal-200 border-teal-800' : 'bg-teal-50 hover:bg-teal-100 text-teal-800 border-teal-200'} px-3 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition border shadow-xs`}
            title={currentLang === 'ar' ? 'Switch to English' : 'التحويل إلى العربية'}
          >
            <Globe className="w-4 h-4 text-teal-400" />
            <span>{currentLang === 'ar' ? 'EN' : 'عربي'}</span>
          </button>
        </div>
      </header>

      {/* AI Assistant Modal */}
      {isAiModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col h-[600px] border border-stone-200 animate-in fade-in zoom-in duration-200">
            {/* Modal Header */}
            <div className="p-5 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-teal-700 text-white flex items-center justify-center shadow-md">
                  <Bot className="w-5 h-5 text-teal-200" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-base">{t('aiAssistant')} (Gemini AI)</h3>
                  <p className="text-xs text-stone-500">{t('aiAssistantSubtitle')}</p>
                </div>
              </div>
              <button
                onClick={() => setIsAiModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-stone-50/50">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex gap-3 ${m.sender === 'user' ? (currentLang === 'en' ? 'justify-end' : 'justify-start flex-row-reverse') : 'justify-start'}`}
                >
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                    m.sender === 'user' ? 'bg-stone-900 text-white font-bold text-xs' : 'bg-teal-700 text-white shadow-sm'
                  }`}>
                    {m.sender === 'user' ? t('you') : <Sparkles className="w-4 h-4 text-teal-200" />}
                  </div>
                  <div className={`p-4 rounded-2xl text-sm max-w-[80%] leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-stone-900 text-white rounded-tl-xs'
                      : 'bg-white text-stone-800 border border-stone-200/80 shadow-xs rounded-tr-xs'
                  }`}>
                    {m.text}
                  </div>
                </div>
              ))}
              {isAiLoading && (
                <div className="flex gap-3 items-center text-stone-400 text-sm">
                  <div className="w-8 h-8 rounded-xl bg-teal-700 text-white flex items-center justify-center shadow-sm">
                    <Loader2 className="w-4 h-4 animate-spin text-teal-200" />
                  </div>
                  <span>{t('aiProcessing')}</span>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendMessage} className="p-4 bg-white border-t border-stone-100 flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder={t('aiPlaceholder')}
                className="flex-1 bg-stone-100 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600 focus:bg-white transition"
              />
              <button
                type="submit"
                disabled={isAiLoading || !chatInput.trim()}
                className="bg-teal-700 text-white px-6 py-3 rounded-2xl text-sm font-semibold hover:bg-teal-800 transition disabled:opacity-50 flex items-center gap-2 shadow-md shadow-teal-700/20"
              >
                <span>{t('send')}</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
