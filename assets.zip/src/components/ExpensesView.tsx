import React, { useState } from 'react';
import { 
  Wallet, 
  Plus, 
  Trash2, 
  Calendar, 
  X, 
  Tag 
} from 'lucide-react';
import { Expense, ClinicSettings } from '../types';

interface ExpensesViewProps {
  expenses: Expense[];
  settings: ClinicSettings;
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onDeleteExpense: (id: string) => void;
}

export function ExpensesView({ expenses, settings, onAddExpense, onDeleteExpense }: ExpensesViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Expense['category']>('Salaries');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !amount) return;

    onAddExpense({
      title: title.trim(),
      category,
      amount: Number(amount),
      date,
      notes: notes.trim()
    });

    setTitle('');
    setAmount('');
    setNotes('');
    setIsModalOpen(false);
  };

  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Operating Expenses Management</h2>
          <p className="text-sm text-stone-500 mt-1">Record and categorize all clinic expenses (salaries, rent, supplies) to provide accurate reports.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-teal-700 text-white px-5 py-3 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
        >
          <Plus className="w-4 h-4 text-teal-200" />
          <span>Record New Expense</span>
        </button>
      </div>

      {/* Stats Card */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">Total Recorded Expenses</span>
          <div className="text-3xl font-extrabold text-stone-900 mt-1">{totalExpenses} <span className="text-sm font-normal text-stone-500">{settings.currency}</span></div>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
          <Wallet className="w-6 h-6" />
        </div>
      </div>

      {/* Expenses List */}
      <div className="bg-white rounded-3xl border border-stone-200/80 shadow-xs overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex items-center justify-between">
          <h3 className="font-bold text-stone-900">Expenses History</h3>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-stone-100 text-stone-600">
            {expenses.length} Items
          </span>
        </div>

        <div className="divide-y divide-stone-100">
          {expenses.length === 0 ? (
            <div className="text-center py-16 text-stone-400 text-sm">
              No expenses recorded yet.
            </div>
          ) : (
            expenses.map((exp) => (
              <div key={exp.id} className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-stone-50/60 transition">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-700 flex items-center justify-center font-bold shrink-0">
                    <Tag className="w-5 h-5 text-amber-600" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <h4 className="font-bold text-stone-900 text-base">{exp.title}</h4>
                      <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800">
                        {exp.category}
                      </span>
                    </div>
                    {exp.notes && <p className="text-xs text-stone-500">{exp.notes}</p>}
                    <span className="text-xs text-stone-400">{exp.date}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 justify-end">
                  <span className="text-base font-extrabold text-stone-900">
                    {exp.amount} <span className="text-xs font-normal text-stone-500">{settings.currency}</span>
                  </span>
                  <button
                    onClick={() => onDeleteExpense(exp.id)}
                    className="p-2 text-stone-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add Expense Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden border border-stone-200 animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-stone-900 text-lg">Record New Expense</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Expense Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Medical Equipment Maintenance"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  >
                    <option value="Salaries">Salaries</option>
                    <option value="Rent">Rent</option>
                    <option value="Supplies">Supplies</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Amount ({settings.currency})</label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="500"
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Notes (Optional)</label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Additional details..."
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 text-white hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
