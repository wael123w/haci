import React, { useState } from 'react';
import { 
  Receipt, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  Printer, 
  X, 
  User 
} from 'lucide-react';
import { Invoice, Patient, ClinicSettings } from '../types';

interface BillingViewProps {
  invoices: Invoice[];
  patients: Patient[];
  settings: ClinicSettings;
  onAddInvoice: (invoice: Omit<Invoice, 'id'>) => void;
  onUpdateInvoiceStatus: (id: string, status: Invoice['status'], paidAmount: number) => void;
}

export function BillingView({ 
  invoices, 
  patients, 
  settings, 
  onAddInvoice, 
  onUpdateInvoiceStatus 
}: BillingViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form state
  const [patientId, setPatientId] = useState(patients[0]?.id || '');
  const [items, setItems] = useState<Array<{ description: string; amount: number }>>([
    { description: 'Consultation Checkup', amount: settings.consultationFee }
  ]);
  const [descInput, setDescInput] = useState('');
  const [amountInput, setAmountInput] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<Invoice['paymentMethod']>('Cash');
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Partial' | 'Unpaid'>('Paid');
  const [paidAmountInput, setPaidAmountInput] = useState('');

  const totalAmount = items.reduce((acc, item) => acc + item.amount, 0);

  const handleAddItem = () => {
    if (!descInput.trim() || !amountInput) return;
    setItems(prev => [...prev, { description: descInput.trim(), amount: Number(amountInput) }]);
    setDescInput('');
    setAmountInput('');
  };

  const handleRemoveItem = (index: number) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const patient = patients.find(p => p.id === patientId);
    if (!patient || items.length === 0) return;

    let paidAmount = 0;
    if (paymentStatus === 'Paid') {
      paidAmount = totalAmount;
    } else if (paymentStatus === 'Unpaid') {
      paidAmount = 0;
    } else {
      paidAmount = Number(paidAmountInput) || 0;
      if (paidAmount <= 0 || paidAmount >= totalAmount) {
        alert('For a partial payment, enter an amount greater than 0 and less than the total amount.');
        return;
      }
    }

    onAddInvoice({
      patientId: patient.id,
      patientName: patient.name,
      items: items.map((it, idx) => ({ id: `it-${idx}`, ...it })),
      totalAmount,
      paidAmount,
      status: paymentStatus,
      date: new Date().toISOString().split('T')[0],
      paymentMethod
    });

    setIsModalOpen(false);
    setPaymentStatus('Paid');
    setPaidAmountInput('');
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Billing & Payments</h2>
          <p className="text-sm text-stone-500 mt-1">Manage invoices, record payments, and track daily accounts and revenue.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-teal-700 text-white px-5 py-3 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
        >
          <Plus className="w-4 h-4 text-teal-200" />
          <span>Issue New Invoice</span>
        </button>
      </div>

      {/* Invoices List */}
      <div className="bg-white rounded-3xl border border-stone-200/80 shadow-xs overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex items-center justify-between">
          <h3 className="font-bold text-stone-900">Invoice History</h3>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-stone-100 text-stone-600">
            {invoices.length} Invoices
          </span>
        </div>

        <div className="divide-y divide-stone-100">
          {invoices.length === 0 ? (
            <div className="text-center py-16 text-stone-400 text-sm">
              No invoices recorded yet.
            </div>
          ) : (
            invoices.map((inv) => (
              <div key={inv.id} className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-stone-50/60 transition">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold shrink-0 border border-emerald-100">
                    <Receipt className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <h4 className="font-bold text-stone-900 text-base">{inv.patientName}</h4>
                      <span className="text-xs font-semibold text-stone-500">{inv.date}</span>
                    </div>
                    <p className="text-xs text-stone-600">
                      {inv.items.map(i => i.description).join(', ')}
                    </p>
                    <div className="text-xs font-bold text-stone-800">
                      Total: <span className="text-teal-700">{inv.totalAmount} {settings.currency}</span> ({inv.paymentMethod})
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 justify-end">
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                    inv.status === 'Paid' || inv.status === 'مدفوعة'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                      : inv.status === 'Partial' || inv.status === 'جزئية'
                      ? 'bg-amber-50 text-amber-700 border border-amber-100'
                      : 'bg-red-50 text-red-700 border border-red-100'
                  }`}>
                    {inv.status}
                  </span>

                  <div className="flex items-center gap-1.5 border-l border-stone-200 pl-3">
                    {inv.status !== 'Paid' && inv.status !== 'مدفوعة' && (
                      <button
                        onClick={() => onUpdateInvoiceStatus(inv.id, 'Paid', inv.totalAmount)}
                        className="px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-emerald-50 hover:text-emerald-700 text-stone-600 transition text-xs font-bold"
                      >
                        Mark as Paid
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* New Invoice Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden border border-stone-200 animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-stone-900 text-lg">Issue New Invoice</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Select Patient</label>
                <select
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                >
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.phone})</option>
                  ))}
                </select>
              </div>

              {/* Items Section */}
              <div className="space-y-2 bg-stone-50 p-4 rounded-2xl border border-stone-200">
                <span className="font-bold text-stone-900 text-sm block">Invoice Items & Services</span>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-2">
                  <input
                    type="text"
                    value={descInput}
                    onChange={(e) => setDescInput(e.target.value)}
                    placeholder="Service description (e.g. Consultation)"
                    className="md:col-span-7 bg-white border border-stone-200 rounded-xl px-3 py-2"
                  />
                  <input
                    type="number"
                    value={amountInput}
                    onChange={(e) => setAmountInput(e.target.value)}
                    placeholder="Amount"
                    className="md:col-span-3 bg-white border border-stone-200 rounded-xl px-3 py-2"
                  />
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="md:col-span-2 bg-teal-700 text-white font-bold rounded-xl px-3 py-2 hover:bg-teal-800 transition"
                  >
                    Add
                  </button>
                </div>

                <div className="space-y-1.5 pt-2">
                  {items.map((it, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-stone-200">
                      <span className="font-bold text-stone-900">{it.description}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-teal-700 font-bold">{it.amount} {settings.currency}</span>
                        <button type="button" onClick={() => handleRemoveItem(idx)} className="text-red-500 hover:text-red-700">×</button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-stone-200 flex items-center justify-between font-bold text-sm text-stone-900">
                  <span>Total Amount:</span>
                  <span className="text-teal-700 text-base">{totalAmount} {settings.currency}</span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Payment Method</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                >
                  <option value="Cash">Cash</option>
                  <option value="Credit Card">Credit Card</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Payment Status</label>
                <select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value as 'Paid' | 'Partial' | 'Unpaid')}
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                >
                  <option value="Paid">Paid in full now</option>
                  <option value="Partial">Partial payment</option>
                  <option value="Unpaid">Unpaid (bill for later)</option>
                </select>
              </div>

              {paymentStatus === 'Partial' && (
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Amount Paid Now</label>
                  <input
                    type="number"
                    value={paidAmountInput}
                    onChange={(e) => setPaidAmountInput(e.target.value)}
                    placeholder={`Less than ${totalAmount}`}
                    max={totalAmount > 0 ? totalAmount - 1 : undefined}
                    min={1}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                  <p className="text-[11px] text-stone-500 mt-1">
                    Remaining: {Math.max(totalAmount - (Number(paidAmountInput) || 0), 0)} {settings.currency}
                  </p>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 text-white hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  Save & Issue Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
