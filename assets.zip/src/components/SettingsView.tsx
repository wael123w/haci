import React, { useState } from 'react';
import { 
  Settings, 
  Save, 
  CheckCircle2, 
  Stethoscope, 
  Globe, 
  HelpCircle, 
  Plus,
  Languages,
  Users as UsersIcon,
  Trash2,
  Key,
  UserCheck,
  Sparkles,
  Building2,
  Image as ImageIcon,
  Eye,
  EyeOff,
  Layers
} from 'lucide-react';
import { ClinicSettings, UserAccount, Department, Doctor } from '../types';
import { defaultArabicTranslations, defaultEnglishTranslations, getTranslation, useTranslation } from '../utils/i18n';

interface SettingsViewProps {
  settings: ClinicSettings;
  onUpdateSettings: (newSettings: ClinicSettings) => void;
}

export function SettingsView({ settings, onUpdateSettings }: SettingsViewProps) {
  const [clinicName, setClinicName] = useState(settings.clinicName);
  const [doctorName, setDoctorName] = useState(settings.doctorName);
  const [specialty, setSpecialty] = useState(settings.specialty);
  const [phone, setPhone] = useState(settings.phone);
  const [email, setEmail] = useState(settings.email);
  const [address, setAddress] = useState(settings.address);
  const [workingHours, setWorkingHours] = useState(settings.workingHours);
  const [currency, setCurrency] = useState(settings.currency);
  const [consultationFee, setConsultationFee] = useState(settings.consultationFee.toString());
  const [supportUrl, setSupportUrl] = useState(settings.supportUrl || 'https://wa.me/966501234567');
  const [language, setLanguage] = useState(settings.language || 'ar');
  const [customLanguages, setCustomLanguages] = useState<Array<{ code: string; name: string; translations: Record<string, string> }>>(settings.customLanguages || []);
  const [clinicLogo, setClinicLogo] = useState(settings.clinicLogo || '');
  const [clinicImage, setClinicImage] = useState(settings.clinicImage || '');
  const [loginBackground, setLoginBackground] = useState(settings.loginBackground || '');
  const [siteFavicon, setSiteFavicon] = useState(settings.siteFavicon || '');
  const [departments, setDepartments] = useState<Department[]>(settings.departments || []);
  const [aiProvider, setAiProvider] = useState<'gemini' | 'openai' | 'anthropic' | 'custom'>(settings.aiProvider || 'gemini');
  const [aiApiKey, setAiApiKey] = useState(settings.aiApiKey || '');
  const [aiCustomEndpoint, setAiCustomEndpoint] = useState(settings.aiCustomEndpoint || '');
  const [darkMode, setDarkMode] = useState(settings.darkMode || false);
  const [showApiKey, setShowApiKey] = useState(false);
  const { t } = useTranslation({ language, customLanguages });

  // Image upload and client-side processing helper
  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (val: string) => void,
    maxWidth = 800,
    maxHeight = 800
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          setter(dataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // New department state
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptDesc, setNewDeptDesc] = useState('');
  const [newDeptDoctor, setNewDeptDoctor] = useState('');
  const [newDeptRoom, setNewDeptRoom] = useState('');

  // Doctors Management state
  const [doctors, setDoctors] = useState<Doctor[]>(settings.doctors || []);
  const [newDocName, setNewDocName] = useState('');
  const [newDocSpecialty, setNewDocSpecialty] = useState('');
  const [newDocPhone, setNewDocPhone] = useState('');
  const [newDocEmail, setNewDocEmail] = useState('');
  const [newDocRoom, setNewDocRoom] = useState('');
  const [newDocWorkingHours, setNewDocWorkingHours] = useState('');

  // Users Management state
  const [users, setUsers] = useState<UserAccount[]>(settings.users || []);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'doctor' | 'receptionist' | 'admin'>('doctor');
  // Draft values for the "reset password" field per existing user row. Kept
  // separate from the stored (hashed) password so we never render or edit
  // the hash directly, and never persist a new password until explicitly submitted.
  const [pendingPasswords, setPendingPasswords] = useState<Record<string, string>>({});

  // New language creation state
  const [newLangCode, setNewLangCode] = useState('');
  const [newLangName, setNewLangName] = useState('');
  const [selectedCustomLangCode, setSelectedCustomLangCode] = useState('');
  const [activeTranslations, setActiveTranslations] = useState<Record<string, string>>({});

  const [savedMessage, setSavedMessage] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      clinicName: clinicName.trim(),
      doctorName: doctorName.trim(),
      specialty: specialty as any,
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      workingHours: workingHours.trim(),
      currency: currency.trim(),
      consultationFee: Number(consultationFee) || 200,
      supportUrl: supportUrl.trim(),
      language,
      clinicLogo: clinicLogo.trim(),
      clinicImage: clinicImage.trim(),
      loginBackground: loginBackground.trim(),
      siteFavicon: siteFavicon.trim(),
      departments,
      doctors,
      aiProvider,
      aiApiKey: aiApiKey.trim(),
      aiCustomEndpoint: aiCustomEndpoint.trim(),
      darkMode,
      customLanguages,
      users
    });

    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 3000);
  };

  const handleAddDoctor = () => {
    if (!newDocName.trim() || !newDocSpecialty.trim()) {
      alert('يرجى إدخال اسم الطبيب وتخصصه على الأقل');
      return;
    }
    const newDoc: Doctor = {
      id: 'doc-' + Date.now(),
      name: newDocName.trim(),
      specialty: newDocSpecialty.trim(),
      phone: newDocPhone.trim() || '0500000000',
      email: newDocEmail.trim() || 'doctor@hakeem.com',
      room: newDocRoom.trim() || 'غرفة 101',
      workingHours: newDocWorkingHours.trim() || '9:00 ص - 5:00 م'
    };
    setDoctors([...doctors, newDoc]);
    setNewDocName('');
    setNewDocSpecialty('');
    setNewDocPhone('');
    setNewDocEmail('');
    setNewDocRoom('');
    setNewDocWorkingHours('');
  };

  const handleDeleteDoctor = (id: string) => {
    setDoctors(doctors.filter(d => d.id !== id));
  };

  const handleAddDepartment = () => {
    if (!newDeptName.trim()) {
      alert('يرجى إدخال اسم القسم على الأقل');
      return;
    }
    const newDept: Department = {
      id: 'dept-' + Date.now(),
      name: newDeptName.trim(),
      description: newDeptDesc.trim(),
      headDoctor: newDeptDoctor.trim() || 'غير محدد',
      room: newDeptRoom.trim() || 'غرفة عامة',
      status: 'active'
    };
    setDepartments([...departments, newDept]);
    setNewDeptName('');
    setNewDeptDesc('');
    setNewDeptDoctor('');
    setNewDeptRoom('');
  };

  const handleDeleteDepartment = (id: string) => {
    setDepartments(departments.filter(d => d.id !== id));
  };

  const handleAIGenerateDepartments = () => {
    const aiDepts: Department[] = [
      { id: 'dept-' + Date.now() + '-1', name: 'قسم العيادات الباطنية المتقدمة', description: 'تشخيص وعلاج الأمراض المزمنة واضطرابات الأيض والسكري', headDoctor: 'د. عبدالله السعيد', room: 'غرفة 201', status: 'active' },
      { id: 'dept-' + Date.now() + '-2', name: 'قسم أمراض القلب والشرايين', description: 'تخطيط القلب التخصصي وفحوصات ضغط الدم والجهد', headDoctor: 'د. ريم خالد', room: 'غرفة 202', status: 'active' },
      { id: 'dept-' + Date.now() + '-3', name: 'قسم الجلدية والتجميل والليزر', description: 'العناية بالبشرة، العلاج بالليزر، وعلاج الأمراض الجلدية', headDoctor: 'د. منى العتيبي', room: 'غرفة 203', status: 'active' },
      { id: 'dept-' + Date.now() + '-4', name: 'قسم العظام وإصابات الملاعب', description: 'جراحة العظام، التأهيل الطبي والعلاج الطبيعي', headDoctor: 'د. فيصل الشمري', room: 'غرفة 204', status: 'active' }
    ];
    setDepartments([...departments, ...aiDepts]);
    alert('تم توليد وتكوين أقسام العيادة بنجاح بواسطة الذكاء الاصطناعي!');
  };

  const handleAddUser = async () => {
    if (!newUsername.trim() || !newPassword.trim() || !newName.trim()) {
      alert('يرجى إكمال اسم المستخدم، كلمة المرور، واسم الحساب');
      return;
    }
    if (users.some(u => u.username.toLowerCase() === newUsername.trim().toLowerCase())) {
      alert('اسم المستخدم موجود مسبقاً، يرجى اختيار اسم آخر');
      return;
    }
    const defaultPerms = newRole === 'admin' 
      ? { dashboard: true, patients: true, appointments: true, records: true, prescriptions: true, billing: true, expenses: true, services: true, medicines: true, settings: true }
      : newRole === 'doctor'
      ? { dashboard: true, patients: true, appointments: true, records: true, prescriptions: true, billing: false, expenses: false, services: true, medicines: true, settings: false }
      : { dashboard: true, patients: true, appointments: true, records: false, prescriptions: false, billing: true, expenses: true, services: false, medicines: false, settings: false };

    const trimmedUsername = newUsername.trim();
    // Sent as plaintext in this local draft only until "Save Settings" is
    // submitted, at which point PUT /api/settings hashes it with bcrypt
    // server-side and this plaintext value never gets stored anywhere —
    // see server/settingsStore.ts.
    const newUser: UserAccount = {
      id: 'u-' + Date.now(),
      username: trimmedUsername,
      password: newPassword.trim(),
      name: newName.trim(),
      role: newRole,
      permissions: defaultPerms
    };
    setUsers([...users, newUser]);
    setNewUsername('');
    setNewPassword('');
    setNewName('');
  };

  const handleDeleteUser = (id: string) => {
    if (users.length <= 1) {
      alert('لا يمكن حذف جميع الحسابات، يجب إبقاء حساب مسؤول واحد على الأقل.');
      return;
    }
    setUsers(users.filter(u => u.id !== id));
  };

  // Resets a user's password to a new value. Held as plaintext in this
  // local draft only until "Save Settings" is submitted, at which point the
  // server bcrypt-hashes it — see server/settingsStore.ts. Never displays
  // or edits a stored hash directly.
  const handleUserPasswordReset = async (id: string, username: string) => {
    const newPass = (pendingPasswords[id] || '').trim();
    if (!newPass) return;
    setUsers(users.map(u => u.id === id ? { ...u, password: newPass } : u));
    setPendingPasswords(prev => ({ ...prev, [id]: '' }));
  };

  const handleTogglePermission = (userId: string, permKey: keyof import('../types').UserPermissions) => {
    setUsers(users.map(u => {
      if (u.id === userId) {
        const currentPerms = u.permissions || { dashboard: true, patients: true, appointments: true, records: true, prescriptions: true, billing: true, expenses: true, services: true, medicines: true, settings: true };
        return {
          ...u,
          permissions: {
            ...currentPerms,
            [permKey]: !currentPerms[permKey]
          }
        };
      }
      return u;
    }));
  };

  const handleAddLanguage = () => {
    if (!newLangCode.trim() || !newLangName.trim()) {
      alert('يرجى إدخال رمز اللغة (مثال: fr) واسم اللغة (مثال: الفرنسية)');
      return;
    }
    const code = newLangCode.trim().toLowerCase();
    if (['ar', 'en'].includes(code) || customLanguages.some(l => l.code === code)) {
      alert('هذه اللغة موجودة مسبقاً');
      return;
    }

    const newLang = {
      code,
      name: newLangName.trim(),
      translations: { ...defaultEnglishTranslations }
    };

    const updated = [...customLanguages, newLang];
    setCustomLanguages(updated);
    setNewLangCode('');
    setNewLangName('');
    setSelectedCustomLangCode(code);
    setActiveTranslations(newLang.translations);
  };

  const handleSelectCustomLang = (code: string) => {
    setSelectedCustomLangCode(code);
    const found = customLanguages.find(l => l.code === code);
    if (found) {
      setActiveTranslations({ ...found.translations });
    }
  };

  const handleTranslationChange = (key: string, value: string) => {
    const updated = { ...activeTranslations, [key]: value };
    setActiveTranslations(updated);
    setCustomLanguages(customLanguages.map(l => l.code === selectedCustomLangCode ? { ...l, translations: updated } : l));
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">{t('settingsSystemAndClinic')}</h2>
          <p className="text-sm text-stone-500 mt-1">{t('settingsSubtitle')}</p>
        </div>
      </div>

      {savedMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl text-sm font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span>{t('savedSuccessfully')}</span>
        </div>
      )}

      {/* Settings Form */}
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl border border-stone-200/80 shadow-xs space-y-8">
        
        {/* Basic Info */}
        <div>
          <h3 className="text-base font-bold text-stone-900 mb-4 flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-teal-700" />
            <span>{t('basicClinicData')}</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('clinicName')}</label>
              <input
                type="text"
                required
                value={clinicName}
                onChange={(e) => setClinicName(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('doctorName')}</label>
              <input
                type="text"
                required
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('specialty')}</label>
              <select
                value={specialty}
                onChange={(e) => setSpecialty(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
              >
                <option value="عام">طب عام</option>
                <option value="نساء وتوليد">نساء وتوليد</option>
                <option value="أسنان">طب وجراحة الأسنان</option>
                <option value="أطفال">طب الأطفال</option>
                <option value="باطنة">أمراض باطنية</option>
                <option value="جلديّة">أمراض جلدية وتجميل</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('phone')}</label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                dir="ltr"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('email')}</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                dir="ltr"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('workingHours')}</label>
              <input
                type="text"
                required
                value={workingHours}
                onChange={(e) => setWorkingHours(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('consultationFee')}</label>
              <input
                type="number"
                required
                value={consultationFee}
                onChange={(e) => setConsultationFee(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('currency')}</label>
              <input
                type="text"
                required
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
              />
            </div>

            <div className="col-span-2">
              <label className="block font-bold text-stone-700 mb-2">{t('address')}</label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
              />
            </div>

            <div className="col-span-2">
              <label className="block font-bold text-stone-700 mb-2 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-teal-700" />
                <span>{t('supportUrl')}</span>
              </label>
              <input
                type="url"
                required
                value={supportUrl}
                onChange={(e) => setSupportUrl(e.target.value)}
                placeholder="https://wa.me/..."
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                dir="ltr"
              />
            </div>
          </div>
        </div>

        {/* Clinic Logo & Location Image Configuration */}
        <div className="pt-6 border-t border-stone-100">
          <h3 className="text-base font-bold text-stone-900 mb-2 flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-teal-700" />
            <span>تكوين ورفع صور العيادة والموقع</span>
          </h3>
          <p className="text-xs text-stone-500 mb-6">
            قم بررفع أو إدخال روابط صور العيادة (الشعار، خلفية تسجيل الدخول، أيقونة المتصفح، وصورة المبنى). يتم معالجة وضغط الصور تلقائياً لضمان توافقها السريع مع مختلف الشاشات.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Clinic Logo */}
            <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200">
              <label className="block font-bold text-stone-700 mb-2">شعار العيادة (Clinic Logo)</label>
              <div className="flex items-center gap-3 mb-3">
                {clinicLogo ? (
                  <img src={clinicLogo} alt="Logo" className="w-14 h-14 rounded-2xl object-cover border border-stone-200 shadow-sm shrink-0" />
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-teal-100 flex items-center justify-center text-teal-800 font-bold shrink-0">شعار</div>
                )}
                <div className="flex-1">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, setClinicLogo, 300, 300)}
                    className="block w-full text-xs text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-teal-700 file:text-white hover:file:bg-teal-800 cursor-pointer"
                  />
                </div>
              </div>
              <input
                type="url"
                value={clinicLogo}
                onChange={(e) => setClinicLogo(e.target.value)}
                placeholder="أو أدخل رابط الشعار مباشرة https://..."
                className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                dir="ltr"
              />
            </div>

            {/* Login Background */}
            <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200">
              <label className="block font-bold text-stone-700 mb-2">خلفية شاشة تسجيل الدخول (Login Background)</label>
              <div className="flex items-center gap-3 mb-3">
                {loginBackground ? (
                  <img src={loginBackground} alt="Login Bg" className="w-14 h-14 rounded-2xl object-cover border border-stone-200 shadow-sm shrink-0" />
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-indigo-100 flex items-center justify-center text-indigo-800 font-bold shrink-0">خلفية</div>
                )}
                <div className="flex-1">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, setLoginBackground, 1200, 800)}
                    className="block w-full text-xs text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 cursor-pointer"
                  />
                </div>
              </div>
              <input
                type="url"
                value={loginBackground}
                onChange={(e) => setLoginBackground(e.target.value)}
                placeholder="أو أدخل رابط الخلفية مباشرة https://..."
                className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                dir="ltr"
              />
            </div>

            {/* Site Favicon / Icon */}
            <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200">
              <label className="block font-bold text-stone-700 mb-2">أيقونة الموقع المفضلة (Favicon)</label>
              <div className="flex items-center gap-3 mb-3">
                {siteFavicon ? (
                  <img src={siteFavicon} alt="Favicon" className="w-10 h-10 rounded-xl object-cover border border-stone-200 shadow-sm shrink-0" />
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-800 font-bold text-xs shrink-0">أيقونة</div>
                )}
                <div className="flex-1">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, setSiteFavicon, 128, 128)}
                    className="block w-full text-xs text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-600 file:text-white hover:file:bg-amber-700 cursor-pointer"
                  />
                </div>
              </div>
              <input
                type="url"
                value={siteFavicon}
                onChange={(e) => setSiteFavicon(e.target.value)}
                placeholder="أو أدخل رابط الأيقونة https://..."
                className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                dir="ltr"
              />
            </div>

            {/* Clinic Location / Building Image */}
            <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200">
              <label className="block font-bold text-stone-700 mb-2">صورة مبنى أو موقع العيادة (Location / Building Image)</label>
              <div className="flex items-center gap-3 mb-3">
                {clinicImage ? (
                  <img src={clinicImage} alt="Clinic Bldg" className="w-14 h-14 rounded-2xl object-cover border border-stone-200 shadow-sm shrink-0" />
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-800 font-bold shrink-0">مبنى</div>
                )}
                <div className="flex-1">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, setClinicImage, 800, 600)}
                    className="block w-full text-xs text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-700 file:text-white hover:file:bg-emerald-800 cursor-pointer"
                  />
                </div>
              </div>
              <input
                type="url"
                value={clinicImage}
                onChange={(e) => setClinicImage(e.target.value)}
                placeholder="أو أدخل رابط صورة المبنى https://..."
                className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                dir="ltr"
              />
            </div>
          </div>
        </div>

        {/* Appearance & Dark Mode */}
        <div className="pt-6 border-t border-stone-100">
          <h3 className="text-base font-bold text-stone-900 mb-2 flex items-center gap-2">
            <Globe className="w-5 h-5 text-teal-700" />
            <span>المظهر والتصميم (Dark Mode)</span>
          </h3>
          <p className="text-xs text-stone-500 mb-6">
            تفعيل الوضع الليلي (الداكن) عالي التباين لراحة العين في العيادة.
          </p>

          <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200 flex items-center justify-between">
            <div>
              <div className="font-bold text-stone-900 text-sm">الوضع الليلي (Dark Mode)</div>
              <div className="text-xs text-stone-500 mt-0.5">تفعيل المظهر الداكن عبر النظام والواجهات وتخزينه محلياً</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={darkMode}
                onChange={(e) => setDarkMode(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-stone-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
            </label>
          </div>
        </div>

        {/* Departments Configuration (Manual or AI) */}
        <div className="pt-6 border-t border-stone-100">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Layers className="w-5 h-5 text-teal-700" />
                <span>أقسام العيادة وتكوينها (يدوياً أو بالذكاء الاصطناعي)</span>
              </h3>
              <p className="text-xs text-stone-500 mt-1">إدارة الأقسام التخصصية وأطباء الأقسام وغرف الكشف.</p>
            </div>
            <button
              type="button"
              onClick={handleAIGenerateDepartments}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-4 py-2.5 rounded-xl text-xs font-bold hover:opacity-90 transition flex items-center gap-2 shadow-sm shrink-0"
            >
              <Sparkles className="w-4 h-4 text-purple-200 animate-pulse" />
              <span>توليد وتكوين الأقسام بالذكاء الاصطناعي</span>
            </button>
          </div>

          {/* Add Department Form */}
          <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200 space-y-4 mb-6">
            <h4 className="font-bold text-stone-900 text-xs flex items-center gap-2">
              <Building2 className="w-4 h-4 text-teal-700" />
              <span>إضافة قسم جديد يدوياً</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              <input
                type="text"
                placeholder="اسم القسم (مثال: قسم العيون)"
                value={newDeptName}
                onChange={(e) => setNewDeptName(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="text"
                placeholder="الوصف المختصر"
                value={newDeptDesc}
                onChange={(e) => setNewDeptDesc(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="text"
                placeholder="رئيس القسم (الطبيب)"
                value={newDeptDoctor}
                onChange={(e) => setNewDeptDoctor(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="text"
                placeholder="رقم الغرفة (مثال: غرفة 105)"
                value={newDeptRoom}
                onChange={(e) => setNewDeptRoom(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <button
                type="button"
                onClick={handleAddDepartment}
                className="bg-teal-700 text-white rounded-xl px-4 py-2.5 font-bold hover:bg-teal-800 transition flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة القسم</span>
              </button>
            </div>
          </div>

          {/* Departments List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {departments.map((dept) => (
              <div key={dept.id} className="bg-stone-50 border border-stone-200 p-4 rounded-2xl flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <h5 className="font-bold text-stone-900 text-sm">{dept.name}</h5>
                    <span className="text-[10px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded-full font-bold">{dept.room}</span>
                  </div>
                  <p className="text-xs text-stone-600 mt-1">{dept.description}</p>
                  <p className="text-[11px] text-stone-500 mt-2 font-medium">رئيس القسم: <span className="text-stone-800 font-bold">{dept.headDoctor}</span></p>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteDepartment(dept.id)}
                  className="text-stone-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition"
                  title="حذف القسم"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Doctors Management Section (System Admin Request) */}
        <div className="pt-6 border-t border-stone-100">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Stethoscope className="w-5 h-5 text-teal-700" />
                <span>إدارة الأطباء وتخصصاتهم (قسم مدير النظام)</span>
              </h3>
              <p className="text-xs text-stone-500 mt-1">إضافة الأطباء الأخصائيين وتحديد تخصصاتهم لتظهر في صفحة حجز المواعيد والكشوفات.</p>
            </div>
          </div>

          {/* Add Doctor Form */}
          <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200 space-y-4 mb-6">
            <h4 className="font-bold text-stone-900 text-xs flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-teal-700" />
              <span>إضافة طبيب جديد للعيادة</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3 text-xs">
              <input
                type="text"
                placeholder="اسم الطبيب (د. محمد...)"
                value={newDocName}
                onChange={(e) => setNewDocName(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="text"
                placeholder="التخصص (مثال: باطنة، أسنان)"
                value={newDocSpecialty}
                onChange={(e) => setNewDocSpecialty(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="text"
                placeholder="رقم الهاتف"
                value={newDocPhone}
                onChange={(e) => setNewDocPhone(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="email"
                placeholder="البريد الإلكتروني"
                value={newDocEmail}
                onChange={(e) => setNewDocEmail(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="text"
                placeholder="الغرفة (غرفة 101)"
                value={newDocRoom}
                onChange={(e) => setNewDocRoom(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <input
                type="text"
                placeholder="ساعات العمل"
                value={newDocWorkingHours}
                onChange={(e) => setNewDocWorkingHours(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <button
                type="button"
                onClick={handleAddDoctor}
                className="bg-teal-700 text-white rounded-xl px-4 py-2.5 font-bold hover:bg-teal-800 transition flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة الطبيب</span>
              </button>
            </div>
          </div>

          {/* Doctors List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {doctors.map((doc) => (
              <div key={doc.id} className="bg-stone-50 border border-stone-200 p-4 rounded-2xl flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-600" />
                    <h5 className="font-bold text-stone-900 text-sm">{doc.name}</h5>
                    <span className="text-[10px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded-full font-bold">{doc.room}</span>
                  </div>
                  <p className="text-xs text-teal-700 font-bold mt-1">التخصص: {doc.specialty}</p>
                  <p className="text-[11px] text-stone-600 mt-1">هاتف: {doc.phone}</p>
                  <p className="text-[11px] text-stone-500 mt-1">ساعات العمل: {doc.workingHours}</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteDoctor(doc.id)}
                  className="text-stone-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition"
                  title="حذف الطبيب"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* AI Key & Provider Configuration Section */}
        <div className="pt-6 border-t border-stone-100">
          <h3 className="text-base font-bold text-stone-900 mb-2 flex items-center gap-2">
            <Key className="w-5 h-5 text-teal-700" />
            <span>إعدادات مفتاح ومزود الذكاء الاصطناعي (AI Provider & API Key)</span>
          </h3>
          <p className="text-xs text-stone-500 mb-4">
            قم بتحديد مزود الذكاء الاصطناعي وإدخال مفتاح الربط الخاص بك (مثل Gemini أو OpenAI أو أي نموذج آخر) لتشغيل ميزات المساعد الذكي وتوليد التقارير.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-2">نوع مزود الذكاء الاصطناعي (AI Provider)</label>
              <select
                value={aiProvider}
                onChange={(e) => setAiProvider(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600 font-semibold text-teal-900"
              >
                <option value="gemini">Google Gemini (Default AI)</option>
                <option value="openai">OpenAI GPT-4 / ChatGPT</option>
                <option value="anthropic">Anthropic Claude</option>
                <option value="custom">Custom Endpoint / API</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-2">مفتاح الربط (API Key)</label>
              <div className="relative">
                <input
                  type={showApiKey ? "text" : "password"}
                  value={aiApiKey}
                  onChange={(e) => setAiApiKey(e.target.value)}
                  placeholder="أدخل مفتاح API (مثال: AIzaSy...)"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600 pr-10"
                  dir="ltr"
                />
                <button
                  type="button"
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700"
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {aiProvider === 'custom' && (
              <div className="col-span-2">
                <label className="block font-bold text-stone-700 mb-2">رابط نقطة النهاية المخصصة (Custom API Endpoint URL)</label>
                <input
                  type="url"
                  value={aiCustomEndpoint}
                  onChange={(e) => setAiCustomEndpoint(e.target.value)}
                  placeholder="https://api.your-custom-ai.com/v1/chat"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  dir="ltr"
                />
              </div>
            )}
          </div>
        </div>

        {/* User Accounts Management Section */}
        <div className="pt-6 border-t border-stone-100">
          <h3 className="text-base font-bold text-stone-900 mb-4 flex items-center gap-2">
            <UsersIcon className="w-5 h-5 text-teal-700" />
            <span>إدارة حسابات المستخدمين (الأطباء، الاستقبال، ومدير النظام)</span>
          </h3>
          <p className="text-xs text-stone-500 mb-4">
            يمكنك إنشاء حسابات الأطباء وموظفي الاستقبال وتعديل أسماء المستخدمين وكلمات المرور الخاصة بهم وبحساب المدير.
          </p>

          {/* Add User Form */}
          <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200 space-y-4 mb-6">
            <h4 className="font-bold text-stone-900 text-xs flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-teal-700" />
              <span>إضافة حساب جديد للنظام</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              <input
                type="text"
                placeholder="اسم المستخدم (Login ID)"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
                dir="ltr"
              />
              <input
                type="text"
                placeholder="كلمة المرور"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
                dir="ltr"
              />
              <input
                type="text"
                placeholder="الاسم الكامل (مثال: د. خالد)"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5"
              />
              <select
                value={newRole}
                onChange={(e) => setNewRole(e.target.value as any)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2.5 font-bold"
              >
                <option value="doctor">طبيب أخصائي</option>
                <option value="receptionist">موظف استقبال</option>
                <option value="admin">مدير النظام</option>
              </select>
              <button
                type="button"
                onClick={handleAddUser}
                className="bg-teal-700 text-white rounded-xl px-4 py-2.5 font-bold hover:bg-teal-800 transition flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة حساب</span>
              </button>
            </div>
          </div>

          {/* Users List */}
          <div className="space-y-4">
            <h4 className="font-bold text-stone-800 text-xs">الحسابات المسجلة وصلاحيات الوصول المخصصة:</h4>
            <div className="grid grid-cols-1 gap-4">
              {users.map((user) => {
                const perms = user.permissions || { dashboard: true, patients: true, appointments: true, records: true, prescriptions: true, billing: true, expenses: true, services: true, medicines: true, settings: true };
                return (
                  <div key={user.id} className="bg-stone-50 border border-stone-200 p-4 rounded-2xl flex flex-col gap-4">
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-sm shrink-0">
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-stone-900 flex items-center gap-2">
                            <span>{user.name}</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                              user.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                              user.role === 'doctor' ? 'bg-teal-100 text-teal-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {user.role === 'admin' ? 'مدير النظام' : user.role === 'doctor' ? 'طبيب' : 'استقبال'}
                            </span>
                          </div>
                          <div className="text-xs text-stone-500 mt-0.5">معرف الدخول: <code className="bg-white px-2 py-0.5 rounded border border-stone-200 text-stone-800 font-mono" dir="ltr">{user.username}</code></div>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                        <div className="flex items-center gap-1">
                          <span className="text-[11px] text-stone-500">كلمة مرور جديدة:</span>
                          <input
                            type="password"
                            value={pendingPasswords[user.id] || ''}
                            onChange={(e) => setPendingPasswords(prev => ({ ...prev, [user.id]: e.target.value }))}
                            placeholder="••••••"
                            className="bg-white border border-stone-200 rounded-xl px-3 py-1.5 text-xs w-28 font-mono"
                            dir="ltr"
                          />
                          <button
                            type="button"
                            onClick={() => handleUserPasswordReset(user.id, user.username)}
                            disabled={!pendingPasswords[user.id]?.trim()}
                            className="bg-teal-50 text-teal-700 hover:bg-teal-100 disabled:opacity-40 disabled:cursor-not-allowed px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition"
                            title="تحديث كلمة المرور"
                          >
                            تحديث
                          </button>
                        </div>
                        {users.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleDeleteUser(user.id)}
                            className="bg-rose-50 text-rose-700 hover:bg-rose-100 p-2 rounded-xl text-xs font-bold transition"
                            title="حذف الحساب"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Permissions Checkboxes */}
                    <div className="border-t border-stone-200 pt-3">
                      <span className="block text-xs font-bold text-stone-700 mb-2">صلاحيات الوصول للأقسام:</span>
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                        {[
                          { key: 'dashboard', label: 'لوحة التحكم' },
                          { key: 'patients', label: 'المرضى' },
                          { key: 'appointments', label: 'المواعيد' },
                          { key: 'records', label: 'الكشوفات' },
                          { key: 'prescriptions', label: 'الروشتات' },
                          { key: 'billing', label: 'الفواتير' },
                          { key: 'expenses', label: 'المصروفات' },
                          { key: 'services', label: 'الخدمات' },
                          { key: 'medicines', label: 'الأدوية' },
                          { key: 'settings', label: 'الإعدادات' },
                        ].map((perm) => (
                          <label key={perm.key} className="flex items-center gap-2 bg-white px-2.5 py-1.5 rounded-xl border border-stone-200 cursor-pointer hover:bg-stone-100 text-xs">
                            <input
                              type="checkbox"
                              checked={!!perms[perm.key as keyof typeof perms]}
                              onChange={() => handleTogglePermission(user.id, perm.key as any)}
                              className="rounded border-stone-300 text-teal-700 focus:ring-teal-500 w-3.5 h-3.5"
                            />
                            <span className="text-stone-700 font-medium">{perm.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Language & Translations Section */}
        <div className="pt-6 border-t border-stone-100">
          <h3 className="text-base font-bold text-stone-900 mb-4 flex items-center gap-2">
            <Globe className="w-5 h-5 text-teal-700" />
            <span>{t('language')}</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs mb-6">
            <div>
              <label className="block font-bold text-stone-700 mb-2">{t('language')}</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600 font-semibold text-teal-800"
              >
                <option value="ar">العربية (Arabic - Default)</option>
                <option value="en">English (الإنجليزية)</option>
                {customLanguages.map(l => (
                  <option key={l.code} value={l.code}>{l.name} ({l.code})</option>
                ))}
              </select>
            </div>
          </div>

          {/* Add New Custom Language */}
          <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200 space-y-4 mb-6">
            <h4 className="font-bold text-stone-900 flex items-center gap-2">
              <Languages className="w-4 h-4 text-teal-700" />
              <span>{t('customLangManagement')}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                placeholder="رمز اللغة (مثال: fr)"
                value={newLangCode}
                onChange={(e) => setNewLangCode(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
              />
              <input
                type="text"
                placeholder="اسم اللغة (مثال: الفرنسية)"
                value={newLangName}
                onChange={(e) => setNewLangName(e.target.value)}
                className="bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
              />
              <button
                type="button"
                onClick={handleAddLanguage}
                className="bg-teal-700 text-white rounded-xl px-4 py-2 text-xs font-bold hover:bg-teal-800 transition flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>إنشاء وتخصيص الترجمات</span>
              </button>
            </div>
          </div>

          {/* Translate custom language keys */}
          {customLanguages.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-stone-700">تعديل وترجمة كلمات اللغة المخصصة:</label>
                <select
                  value={selectedCustomLangCode}
                  onChange={(e) => handleSelectCustomLang(e.target.value)}
                  className="bg-stone-50 border border-stone-200 rounded-xl px-3 py-1.5 text-xs font-bold text-teal-800"
                >
                  <option value="">اختر لغة للتعديل...</option>
                  {customLanguages.map(l => (
                    <option key={l.code} value={l.code}>{l.name}</option>
                  ))}
                </select>
              </div>

              {selectedCustomLangCode && (
                <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 max-h-64 overflow-y-auto space-y-3">
                  <p className="text-[11px] text-stone-500 mb-2">قم بتعديل الكلمات المقابلة لكل مفتاح في النظام:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {Object.keys(defaultArabicTranslations).map(key => (
                      <div key={key} className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-stone-200">
                        <span className="w-32 text-[11px] font-mono text-stone-500 truncate" title={key}>{key} ({defaultArabicTranslations[key]})</span>
                        <input
                          type="text"
                          value={activeTranslations[key] || ''}
                          onChange={(e) => handleTranslationChange(key, e.target.value)}
                          className="flex-1 bg-stone-50 border border-stone-200 rounded-lg px-2 py-1 text-xs"
                          placeholder="الترجمة..."
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex justify-end pt-6 border-t border-stone-100">
          <button
            type="submit"
            className="flex items-center gap-2 bg-teal-700 text-white px-8 py-3.5 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-lg shadow-teal-700/20"
          >
            <Save className="w-4 h-4 text-teal-200" />
            <span>{t('saveSettings')}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
