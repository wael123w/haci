import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  FileHeart, 
  FileText, 
  Receipt, 
  Wallet, 
  Stethoscope, 
  Pill, 
  Settings, 
  ShieldCheck,
  X,
  UserCheck
} from 'lucide-react';
import { ActiveTab, ClinicSettings } from '../types';
import { useTranslation } from '../utils/i18n';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  clinicName: string;
  isOpen?: boolean;
  onClose?: () => void;
  currentUser?: { name: string; username?: string; role: 'doctor' | 'receptionist' | 'admin'; specialty: string; permissions?: Record<string, boolean> };
  settings?: ClinicSettings;
}

export function Sidebar({ activeTab, setActiveTab, clinicName, isOpen, onClose, currentUser, settings }: SidebarProps) {
  const { t, currentLang } = useTranslation(settings);

  const allNavItems = [
    { id: 'dashboard' as ActiveTab, label: t('dashboard'), icon: LayoutDashboard, roles: ['doctor', 'receptionist', 'admin'] },
    { id: 'patients' as ActiveTab, label: t('patients'), icon: Users, roles: ['doctor', 'receptionist', 'admin'] },
    { id: 'appointments' as ActiveTab, label: t('appointments'), icon: Calendar, roles: ['doctor', 'receptionist', 'admin'] },
    { id: 'records' as ActiveTab, label: t('records'), icon: FileHeart, roles: ['doctor', 'admin'] },
    { id: 'prescriptions' as ActiveTab, label: t('prescriptions'), icon: FileText, roles: ['doctor', 'admin'] },
    { id: 'billing' as ActiveTab, label: t('billing'), icon: Receipt, roles: ['receptionist', 'admin'] },
    { id: 'expenses' as ActiveTab, label: t('expenses'), icon: Wallet, roles: ['receptionist', 'admin'] },
    { id: 'services' as ActiveTab, label: t('services'), icon: Stethoscope, roles: ['doctor', 'admin'] },
    { id: 'medicines' as ActiveTab, label: t('medicines'), icon: Pill, roles: ['doctor', 'admin'] },
    { id: 'settings' as ActiveTab, label: t('settings'), icon: Settings, roles: ['admin'] },
  ];

  const roleNameArabic = currentUser?.role === 'doctor' ? t('medicalDoctor') : currentUser?.role === 'receptionist' ? t('receptionist') : t('systemAdmin');

  const navItems = allNavItems.filter(item => {
    if (!currentUser) return true;
    const matchedUser = settings?.users?.find(u => u.username === currentUser.username || u.name === currentUser.name);
    const perms = matchedUser?.permissions || currentUser.permissions;
    if (perms && perms[item.id] !== undefined) {
      return perms[item.id];
    }
    return item.roles.includes(currentUser.role);
  });

  const sidebarContent = (
    <div className={`w-72 ${settings?.darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'} border-l flex flex-col h-full shadow-xs`}>
      <div className={`p-6 border-b ${settings?.darkMode ? 'border-stone-800' : 'border-stone-100'} flex items-center justify-between`}>
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-teal-700 text-white flex items-center justify-center font-bold shadow-md shadow-teal-700/20">
            <Stethoscope className="w-6 h-6 text-teal-100" />
          </div>
          <div className="overflow-hidden">
            <h1 className={`font-bold ${settings?.darkMode ? 'text-stone-100' : 'text-stone-900'} text-base truncate`}>{clinicName}</h1>
            <p className="text-xs text-teal-500 font-semibold flex items-center gap-1 mt-0.5">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
              <span>{t('systemPro')}</span>
            </p>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="md:hidden text-stone-400 hover:text-stone-200 p-1">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {currentUser && (
        <div className="px-4 pt-4 pb-2">
          <div className={`${settings?.darkMode ? 'bg-stone-800 border-stone-700 text-stone-100' : 'bg-stone-50 border-stone-200/80 text-stone-900'} border p-3 rounded-2xl flex items-center gap-3`}>
            <div className="w-9 h-9 rounded-xl bg-teal-900 text-teal-200 flex items-center justify-center font-bold text-xs shrink-0">
              {currentUser.name.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <div className={`text-xs font-bold ${settings?.darkMode ? 'text-stone-100' : 'text-stone-900'} truncate`}>{currentUser.name}</div>
              <div className="text-[10px] text-teal-400 font-semibold">{roleNameArabic}</div>
            </div>
          </div>
        </div>
      )}

      <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                if (onClose) onClose();
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-teal-700 text-white shadow-md shadow-teal-700/20 font-semibold'
                  : settings?.darkMode
                  ? 'text-stone-300 hover:bg-stone-800 hover:text-stone-100'
                  : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-teal-200' : settings?.darkMode ? 'text-stone-400' : 'text-stone-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className={`p-4 border-t ${settings?.darkMode ? 'border-stone-800' : 'border-stone-100'}`}>
        <div className={`${settings?.darkMode ? 'bg-stone-800 border-stone-700 text-stone-200' : 'bg-teal-50/80 border-teal-100 text-teal-900'} rounded-2xl p-3.5 border text-xs`}>
          <div className="flex items-center justify-between font-bold mb-1">
            <span>{t('customPermission')}</span>
            <span className={`px-2 py-0.5 rounded-md text-[10px] ${settings?.darkMode ? 'bg-teal-900 text-teal-200' : 'bg-teal-200/60 text-teal-800'}`}>{roleNameArabic}</span>
          </div>
          <p className={`${settings?.darkMode ? 'text-stone-400' : 'text-teal-700'} leading-relaxed text-[11px]`}>
            {t('customPermissionDesc')}
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col h-screen shrink-0">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs" onClick={onClose} />
          <div className="relative z-10 w-72 bg-white h-full shadow-2xl animate-in slide-in-from-right duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}
