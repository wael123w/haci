import React, { useState } from 'react';
import { 
  Stethoscope, 
  Plus, 
  Trash2, 
  X, 
  Clock, 
  Tag 
} from 'lucide-react';
import { Service, ClinicSettings } from '../types';

interface ServicesViewProps {
  services: Service[];
  settings: ClinicSettings;
  onAddService: (service: Omit<Service, 'id'>) => void;
  onDeleteService: (id: string) => void;
}

export function ServicesView({ services, settings, onAddService, onDeleteService }: ServicesViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Consultations');
  const [price, setPrice] = useState('');
  const [durationMinutes, setDurationMinutes] = useState('30');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !price) return;

    onAddService({
      name: name.trim(),
      category: category.trim(),
      price: Number(price),
      durationMinutes: Number(durationMinutes) || 30
    });

    setName('');
    setPrice('');
    setIsModalOpen(false);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Clinic Services & Pricing</h2>
          <p className="text-sm text-stone-500 mt-1">Integrated module to add and manage medical services offered by the clinic and set their pricing.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-teal-700 text-white px-5 py-3 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
        >
          <Plus className="w-4 h-4 text-teal-200" />
          <span>Add New Service</span>
        </button>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {services.map((srv) => (
          <div key={srv.id} className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col justify-between space-y-4 hover:border-teal-500/50 transition">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-teal-50 text-teal-800 mb-2 inline-block">
                  {srv.category}
                </span>
                <h3 className="font-bold text-stone-900 text-lg">{srv.name}</h3>
              </div>
              <button
                onClick={() => onDeleteService(srv.id)}
                className="p-2 text-stone-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-stone-100 text-xs">
              <span className="text-stone-500 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{srv.durationMinutes} mins</span>
              </span>
              <span className="text-lg font-extrabold text-teal-700">
                {srv.price} <span className="text-xs font-normal text-stone-500">{settings.currency}</span>
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden border border-stone-200 animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-stone-900 text-lg">Add New Medical Service</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Service Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Laser Dental Cleaning"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Category</label>
                  <input
                    type="text"
                    required
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Price ({settings.currency})</label>
                  <input
                    type="number"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="250"
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Duration (Mins)</label>
                  <input
                    type="number"
                    required
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 text-white hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  Save Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
