import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Printer, 
  Trash2, 
  Stethoscope, 
  Pill, 
  Check, 
  X, 
  Sparkles, 
  User 
} from 'lucide-react';
import { Prescription, Patient, Medicine, ClinicSettings } from '../types';

interface PrescriptionsViewProps {
  prescriptions: Prescription[];
  patients: Patient[];
  medicines: Medicine[];
  settings: ClinicSettings;
  onAddPrescription: (prescription: Omit<Prescription, 'id'>) => void;
}

export function PrescriptionsView({ 
  prescriptions, 
  patients, 
  medicines, 
  settings, 
  onAddPrescription 
}: PrescriptionsViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [printModalPrescription, setPrintModalPrescription] = useState<Prescription | null>(null);

  // Form state
  const [patientId, setPatientId] = useState(patients[0]?.id || '');
  const [diagnosis, setDiagnosis] = useState('');
  const [advice, setAdvice] = useState('Complete rest, drink plenty of warm fluids, and consult the clinic if symptoms persist.');
  
  // Medications list
  const [rxList, setRxList] = useState<Array<{ name: string; dosage: string; frequency: string; duration: string; notes?: string }>>([
    { name: medicines[0]?.name || 'Panadol', dosage: '500 mg', frequency: 'Every 8 hours', duration: '5 days', notes: 'After meals' }
  ]);

  // Tests list
  const [testList, setTestList] = useState<Array<{ name: string; notes?: string }>>([
    { name: 'Complete Blood Count (CBC)' }
  ]);

  const [selectedMedName, setSelectedMedName] = useState(medicines[0]?.name || '');
  const [medDosage, setMedDosage] = useState('500 mg');
  const [medFreq, setMedFreq] = useState('Once daily');
  const [medDuration, setMedDuration] = useState('7 days');
  const [medNotes, setMedNotes] = useState('');

  const [testName, setTestName] = useState('');

  const handleAddMed = () => {
    if (!selectedMedName) return;
    setRxList(prev => [...prev, { name: selectedMedName, dosage: medDosage, frequency: medFreq, duration: medDuration, notes: medNotes }]);
    setMedNotes('');
  };

  const handleRemoveMed = (index: number) => {
    setRxList(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddTest = () => {
    if (!testName.trim()) return;
    setTestList(prev => [...prev, { name: testName.trim() }]);
    setTestName('');
  };

  const handleRemoveTest = (index: number) => {
    setTestList(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const patient = patients.find(p => p.id === patientId);
    if (!patient || rxList.length === 0) return;

    onAddPrescription({
      patientId: patient.id,
      patientName: patient.name,
      date: new Date().toISOString().split('T')[0],
      diagnosis: diagnosis.trim() || 'General Diagnosis',
      medications: rxList,
      tests: testList,
      advice: advice.trim(),
      doctorName: settings.doctorName
    });

    setDiagnosis('');
    setIsModalOpen(false);
  };

  const handlePrint = (prescription: Prescription) => {
    setPrintModalPrescription(prescription);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Electronic Medical Prescriptions</h2>
          <p className="text-sm text-stone-500 mt-1">Create and print professional medical prescriptions with medicine and test management.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-teal-700 text-white px-5 py-3 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
        >
          <Plus className="w-4 h-4 text-teal-200" />
          <span>New Prescription</span>
        </button>
      </div>

      {/* Prescriptions List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {prescriptions.length === 0 ? (
          <div className="col-span-full text-center py-16 bg-white rounded-3xl border border-stone-200/80 text-stone-400 text-sm">
            No prescriptions recorded yet.
          </div>
        ) : (
          prescriptions.map((rx) => (
            <div key={rx.id} className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs space-y-4 hover:border-teal-500/50 transition flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-3 mb-3 pb-3 border-b border-stone-100">
                  <div>
                    <h3 className="font-bold text-stone-900 text-lg">{rx.patientName}</h3>
                    <p className="text-xs text-stone-500">{rx.doctorName} • {rx.date}</p>
                  </div>
                  <button
                    onClick={() => handlePrint(rx)}
                    className="flex items-center gap-1.5 bg-teal-50 text-teal-800 hover:bg-teal-100 px-3.5 py-2 rounded-xl text-xs font-bold transition border border-teal-200"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Prescription</span>
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <span className="font-bold text-stone-800 block mb-1">Diagnosis: </span>
                    <span className="text-stone-700 font-semibold">{rx.diagnosis}</span>
                  </div>

                  <div>
                    <span className="font-bold text-stone-800 block mb-1">Prescribed Medications:</span>
                    <ul className="space-y-1 bg-stone-50 p-3 rounded-2xl border border-stone-100">
                      {rx.medications.map((m, idx) => (
                        <li key={idx} className="flex items-center justify-between">
                          <span className="font-bold text-teal-900">• {m.name} ({m.dosage})</span>
                          <span className="text-stone-500">{m.frequency} - {m.duration}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {rx.tests && rx.tests.length > 0 && (
                    <div>
                      <span className="font-bold text-stone-800 block mb-1">Required Tests:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {rx.tests.map((t, idx) => (
                          <span key={idx} className="bg-teal-50 text-teal-800 border border-teal-100 px-2.5 py-1 rounded-xl text-[11px] font-semibold">
                            {t.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {rx.advice && (
                    <div className="bg-amber-50/60 p-3 rounded-2xl border border-amber-100/60 text-amber-900">
                      <span className="font-bold block mb-0.5">Medical Advice:</span>
                      <p className="text-amber-800/90 leading-relaxed">{rx.advice}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* New Prescription Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden border border-stone-200 my-8">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-stone-900 text-lg">Create New Electronic Prescription</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Select Patient</label>
                <select
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                >
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.phone})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Diagnosis</label>
                <input
                  type="text"
                  required
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  placeholder="e.g. Acute bronchitis, Hypertension review..."
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              {/* Medications Adder */}
              <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-3">
                <span className="font-bold text-stone-900 text-sm block">Add Medications</span>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-2">
                  <select
                    value={selectedMedName}
                    onChange={(e) => setSelectedMedName(e.target.value)}
                    className="md:col-span-4 bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                  >
                    {medicines.map(m => (
                      <option key={m.id} value={m.name}>{m.name} ({m.concentration})</option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={medDosage}
                    onChange={(e) => setMedDosage(e.target.value)}
                    placeholder="Dosage"
                    className="md:col-span-2 bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                  />
                  <input
                    type="text"
                    value={medFreq}
                    onChange={(e) => setMedFreq(e.target.value)}
                    placeholder="Frequency"
                    className="md:col-span-3 bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                  />
                  <input
                    type="text"
                    value={medDuration}
                    onChange={(e) => setMedDuration(e.target.value)}
                    placeholder="Duration"
                    className="md:col-span-3 bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                  />
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={medNotes}
                    onChange={(e) => setMedNotes(e.target.value)}
                    placeholder="Notes (e.g. After meals)"
                    className="flex-1 bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddMed}
                    className="bg-teal-700 text-white font-bold px-4 py-2 rounded-xl text-xs hover:bg-teal-800 transition"
                  >
                    Add Med
                  </button>
                </div>

                <div className="space-y-1.5 pt-1">
                  {rxList.map((m, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-stone-200">
                      <div>
                        <span className="font-bold text-stone-900">{m.name} ({m.dosage})</span>
                        <span className="text-stone-500 ml-2">• {m.frequency} for {m.duration} {m.notes ? `(${m.notes})` : ''}</span>
                      </div>
                      <button type="button" onClick={() => handleRemoveMed(idx)} className="text-red-500 hover:text-red-700">×</button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tests Adder */}
              <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-3">
                <span className="font-bold text-stone-900 text-sm block">Required Lab / Radiology Tests</span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={testName}
                    onChange={(e) => setTestName(e.target.value)}
                    placeholder="Test Name (e.g. CBC, Lipid Profile, Chest X-Ray)"
                    className="flex-1 bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddTest}
                    className="bg-teal-700 text-white font-bold px-4 py-2 rounded-xl text-xs hover:bg-teal-800 transition"
                  >
                    Add Test
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {testList.map((t, idx) => (
                    <span key={idx} className="bg-white border border-stone-200 px-3 py-1 rounded-xl text-xs font-bold text-stone-800 flex items-center gap-2">
                      {t.name}
                      <button type="button" onClick={() => handleRemoveTest(idx)} className="text-red-500 hover:text-red-700">×</button>
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Medical Advice</label>
                <textarea
                  rows={2}
                  value={advice}
                  onChange={(e) => setAdvice(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 text-white hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  Save & Issue Prescription
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Print Modal */}
      {printModalPrescription && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden border border-stone-200 p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-stone-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-teal-700 text-white flex items-center justify-center font-bold">
                  <Stethoscope className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-xl">{settings.clinicName}</h3>
                  <p className="text-xs text-stone-500">{settings.specialty} • {settings.phone}</p>
                </div>
              </div>
              <div className="text-right text-xs text-stone-500 font-semibold">
                <div>Date: {printModalPrescription.date}</div>
                <div>Doctor: {printModalPrescription.doctorName}</div>
              </div>
            </div>

            <div className="space-y-4 text-sm">
              <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 flex items-center justify-between">
                <div>
                  <span className="text-xs text-stone-500 block">Patient Name</span>
                  <span className="font-bold text-stone-900 text-base">{printModalPrescription.patientName}</span>
                </div>
                <div>
                  <span className="text-xs text-stone-500 block">Diagnosis</span>
                  <span className="font-bold text-teal-800 text-base">{printModalPrescription.diagnosis}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Pill className="w-4 h-4 text-teal-700" />
                  Rx - Prescribed Medications
                </h4>
                <div className="space-y-2">
                  {printModalPrescription.medications.map((m, idx) => (
                    <div key={idx} className="p-3 rounded-2xl border border-stone-200 bg-white flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-stone-900 text-sm">{idx + 1}. {m.name}</span>
                        <span className="ml-2 text-teal-700 font-semibold">({m.dosage})</span>
                        {m.notes && <p className="text-stone-500 mt-0.5">{m.notes}</p>}
                      </div>
                      <div className="text-right font-semibold text-stone-700">
                        {m.frequency} • {m.duration}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {printModalPrescription.tests && printModalPrescription.tests.length > 0 && (
                <div className="space-y-1.5">
                  <h4 className="font-bold text-stone-900 text-xs">Required Investigations / Tests:</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {printModalPrescription.tests.map((t, idx) => (
                      <span key={idx} className="bg-stone-100 text-stone-800 px-3 py-1 rounded-xl text-xs font-semibold">
                        • {t.name}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {printModalPrescription.advice && (
                <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200 text-xs">
                  <span className="font-bold block mb-1 text-stone-900">Physician's Advice:</span>
                  <p className="text-stone-700 leading-relaxed">{printModalPrescription.advice}</p>
                </div>
              )}
            </div>

            <div className="pt-6 border-t border-stone-200 flex items-center justify-between">
              <div className="text-xs text-stone-400">
                Clinic Address: {settings.address}
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setPrintModalPrescription(null)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Close
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-2 bg-teal-700 text-white px-6 py-2.5 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Now</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
