import React, { useState } from 'react';
import { 
  Stethoscope, 
  Lock, 
  User, 
  ShieldCheck, 
  KeyRound, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2,
  Building2,
  Phone,
  HeartPulse
} from 'lucide-react';
import { ClinicSettings, UserAccount } from '../types';
import { useTranslation } from '../utils/i18n';
import { api, setToken, ApiError } from '../utils/api';

interface LoginViewProps {
  settings: ClinicSettings;
  onLogin: (user: UserAccount) => void;
}

export function LoginView({ settings, onLogin }: LoginViewProps) {
  const { t, currentLang } = useTranslation(settings);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError(t('loginError1'));
      return;
    }

    setIsLoading(true);
    try {
      // Verified server-side against the bcrypt hash stored in MySQL —
      // see server/routes.ts (/api/auth/login) and server/settingsStore.ts.
      const { token, user } = await api.login(username.trim(), password);
      setToken(token);
      onLogin(user as UserAccount);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : t('loginError2'));
    } finally {
      setIsLoading(false);
    }
  };



  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8 relative bg-cover bg-center bg-stone-900"
      style={settings.loginBackground ? { backgroundImage: `url(${settings.loginBackground})` } : {}}
      dir={currentLang === 'en' ? 'ltr' : 'rtl'}
    >
      {settings.loginBackground && <div className="absolute inset-0 bg-stone-950/75 backdrop-blur-xs" />}
      <div className="max-w-5xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 border border-stone-100 relative z-10">
        
        {/* Left/Top Branding Panel */}
        <div className="lg:col-span-5 bg-gradient-to-br from-teal-900 via-teal-800 to-emerald-900 p-8 sm:p-12 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="absolute -top-24 -right-24 w-72 h-72 bg-teal-600/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-8">
              {settings.clinicLogo ? (
                <img src={settings.clinicLogo} alt="Logo" className="w-12 h-12 rounded-2xl object-cover border border-white/20 shadow-lg shrink-0" />
              ) : (
                <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-lg">
                  <Stethoscope className="w-7 h-7 text-teal-200" />
                </div>
              )}
              <div>
                <span className="text-xs uppercase tracking-wider text-teal-300 font-semibold">{settings.specialty ? `${t('specialClinic')} (${settings.specialty})` : t('smartClinicSystem')}</span>
                <h1 className="text-xl font-bold text-white">{settings.clinicName || t('systemPro')}</h1>
              </div>
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-4 leading-snug">
              {t('comprehensivePortal')}
            </h2>
            <p className="text-teal-100/80 text-sm leading-relaxed mb-8">
              {t('comprehensiveDesc')}
            </p>

            <div className="space-y-3 pt-4 border-t border-teal-700/50">
              <div className="flex items-center gap-3 text-sm text-teal-100">
                <div className="w-6 h-6 rounded-full bg-teal-800 flex items-center justify-center text-teal-300 shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span>{t('secureEncryption')}</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-teal-100">
                <div className="w-6 h-6 rounded-full bg-teal-800 flex items-center justify-center text-teal-300 shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span>{t('aiAssistantFeature')}</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-teal-100">
                <div className="w-6 h-6 rounded-full bg-teal-800 flex items-center justify-center text-teal-300 shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span>{t('financialMgmt')}</span>
              </div>
            </div>
          </div>

          <div className="relative z-10 pt-8 mt-8 border-t border-teal-700/50 flex items-center justify-between text-xs text-teal-200">
            <span>{settings.clinicName}</span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{t('officialLicense')}</span>
            </span>
          </div>
        </div>

        {/* Right Form Panel */}
        <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-center bg-stone-50/50">
          <div className="max-w-md w-full mx-auto">
            <div className="mb-8">
              <div className="inline-flex items-center gap-2 bg-teal-50 text-teal-800 px-3 py-1 rounded-full text-xs font-semibold mb-3 border border-teal-200">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('secureLogin')}</span>
              </div>
              <h2 className="text-2xl font-bold text-stone-900">{t('welcomeBack')}</h2>
              <p className="text-sm text-stone-500 mt-1">{t('loginPrompt')}</p>
            </div>


            {error && (
              <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl text-sm font-medium flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">{t('usernameLabel')}</label>
                <div className="relative">
                  <div className={`absolute inset-y-0 ${currentLang === 'en' ? 'left-0 pl-3.5' : 'right-0 pr-3.5'} flex items-center pointer-events-none text-stone-400`}>
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="admin / doctor"
                    className={`w-full bg-white border border-stone-200 rounded-xl ${currentLang === 'en' ? 'pl-10 pr-4' : 'pr-10 pl-4'} py-3 text-sm text-stone-900 focus:outline-hidden focus:border-teal-600 focus:ring-2 focus:ring-teal-600/10 transition`}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">{t('passwordLabel')}</label>
                <div className="relative">
                  <div className={`absolute inset-y-0 ${currentLang === 'en' ? 'left-0 pl-3.5' : 'right-0 pr-3.5'} flex items-center pointer-events-none text-stone-400`}>
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full bg-white border border-stone-200 rounded-xl ${currentLang === 'en' ? 'pl-10 pr-4' : 'pr-10 pl-4'} py-3 text-sm text-stone-900 focus:outline-hidden focus:border-teal-600 focus:ring-2 focus:ring-teal-600/10 transition`}
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-sm py-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 text-teal-700 border-stone-300 rounded focus:ring-teal-600"
                  />
                  <span className="text-xs text-stone-600 font-medium">{t('rememberMe')}</span>
                </label>
                <a href="#forgot" onClick={(e) => { e.preventDefault(); alert(currentLang === 'en' ? 'Please contact system admin to reset password.' : 'يرجى مراجعة مسؤول النظام لإعادة تعيين كلمة المرور الخاصة بك.'); }} className="text-xs text-teal-700 hover:text-teal-800 font-semibold">
                  {t('forgotPassword')}
                </a>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-stone-900 hover:bg-stone-800 text-white py-3.5 rounded-xl font-bold text-sm transition shadow-lg shadow-stone-900/10 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <span>{t('loggingIn')}</span>
                ) : (
                  <>
                    <span>{t('loginBtn')}</span>
                    <ArrowRight className={`w-4 h-4 ${currentLang === 'en' ? 'rotate-180' : ''}`} />
                  </>
                )}
              </button>
            </form>

            <div className="mt-8 pt-6 border-t border-stone-200 text-center">
              <p className="text-xs text-stone-500 font-medium">
                {t('needSupport')}{' '}
                <a href={settings.supportUrl || 'https://wa.me/966501234567'} target="_blank" rel="noopener noreferrer" className="text-teal-700 font-bold hover:underline">
                  {t('contactSupport')}
                </a>
              </p>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}

