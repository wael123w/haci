import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Calendar, 
  Receipt, 
  Wallet, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  ArrowLeft, 
  Stethoscope, 
  AlertCircle,
  BellRing,
  Timer
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart,
  Pie,
  Cell,
  Legend,
  BarChart,
  Bar
} from 'recharts';
import { Patient, Appointment, Invoice, Expense, ActiveTab, ClinicSettings } from '../types';

interface DashboardViewProps {
  patients: Patient[];
  appointments: Appointment[];
  invoices: Invoice[];
  expenses: Expense[];
  setActiveTab: (tab: ActiveTab) => void;
  settings?: ClinicSettings;
}

export function DashboardView({ 
  patients, 
  appointments, 
  invoices, 
  expenses, 
  setActiveTab,
  settings 
}: DashboardViewProps) {
  const totalRevenue = invoices
    .filter(i => (i.status as string) === 'Paid' || (i.status as string) === 'Partial' || (i.status as string) === 'مدفوعة' || (i.status as string) === 'جزئية')
    .reduce((acc, i) => acc + i.paidAmount, 0);

  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const netProfit = totalRevenue - totalExpenses;
  const todayAppointments = appointments.filter(a => a.date === new Date().toISOString().split('T')[0]);

  const [upcomingAlerts, setUpcomingAlerts] = useState<Appointment[]>([]);

  useEffect(() => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTotalMinutes = currentHour * 60 + currentMinute;

    const upcoming = appointments.filter(app => {
      if (!app.time) return false;
      const [hoursStr, minutesStr] = app.time.split(':');
      if (!hoursStr || !minutesStr) return false;
      const appHour = parseInt(hoursStr, 10);
      const appMinute = parseInt(minutesStr.replace(/(AM|PM|ص|م)/gi, '').trim(), 10);
      
      let totalAppMinutes = appHour * 60 + appMinute;
      if (app.time.includes('PM') && appHour < 12) totalAppMinutes += 12 * 60;

      const diff = totalAppMinutes - currentTotalMinutes;
      const st = app.status as string;
      return diff >= 0 && diff <= 60 && st !== 'Completed' && st !== 'Cancelled' && st !== 'مكتمل' && st !== 'ملغي';
    });

    setUpcomingAlerts(upcoming);
  }, [appointments]);

  const monthlyRevenueData = [
    { month: 'Jan', Income: 12400, Expenses: 3200 },
    { month: 'Feb', Income: 15200, Expenses: 4100 },
    { month: 'Mar', Income: 18500, Expenses: 4800 },
    { month: 'Apr', Income: 14900, Expenses: 3900 },
    { month: 'May', Income: 21000, Expenses: 5200 },
    { month: 'Jun', Income: 24500, Expenses: 6000 },
    { month: 'Jul', Income: totalRevenue || 19800, Expenses: totalExpenses || 4500 },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      
      {/* Upcoming Appointments Alert Banner (Next Hour) */}
      {upcomingAlerts.length > 0 && (
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white p-5 rounded-3xl shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4 border border-amber-400/30">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0 animate-bounce">
              <BellRing className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-white/20 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">Upcoming Alert</span>
                <span className="text-xs text-amber-100 font-medium">Next 1 Hour</span>
              </div>
              <h3 className="text-base font-bold mt-1">
                You have {upcomingAlerts.length} upcoming appointments ready
              </h3>
            </div>
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
            {upcomingAlerts.map(app => (
              <div key={app.id} className="bg-white/15 backdrop-blur-md border border-white/20 px-4 py-2 rounded-2xl flex items-center gap-3 shrink-0">
                <div className="text-left">
                  <div className="text-xs font-bold text-white">{app.patientName}</div>
                  <div className="text-[10px] text-amber-100 flex items-center gap-1">
                    <Timer className="w-3 h-3" />
                    <span>Time: {app.time}</span>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('appointments')}
                  className="bg-white text-amber-900 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-amber-50 transition"
                >
                  View
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-teal-900 text-white p-8 rounded-3xl shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute -left-10 -bottom-10 w-60 h-60 bg-white/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 space-y-2">
          <div className="inline-flex items-center gap-2 bg-teal-700/60 text-teal-200 px-3 py-1 rounded-full text-xs font-semibold">
            <Stethoscope className="w-3.5 h-3.5" />
            <span>{settings?.clinicName || 'Medical Clinic'} - Dashboard</span>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight">Welcome back, Dr. {settings?.doctorName || 'Doctor'}</h1>
          <p className="text-teal-100/90 text-sm max-w-xl">
            Here is your daily clinical overview. You have {todayAppointments.length} appointments scheduled for today.
          </p>
        </div>
        <div className="relative z-10 flex items-center gap-3">
          <button
            onClick={() => setActiveTab('appointments')}
            className="bg-white text-teal-900 px-6 py-3.5 rounded-2xl text-sm font-bold hover:bg-teal-50 transition shadow-lg flex items-center gap-2"
          >
            <Calendar className="w-4 h-4 text-teal-700" />
            <span>Today's Calendar</span>
          </button>
          <button
            onClick={() => setActiveTab('patients')}
            className="bg-teal-700/80 hover:bg-teal-700 text-white border border-teal-600 px-6 py-3.5 rounded-2xl text-sm font-bold transition flex items-center gap-2"
          >
            <Users className="w-4 h-4 text-teal-200" />
            <span>Patients</span>
          </button>
        </div>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <div 
          onClick={() => setActiveTab('patients')}
          className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer flex items-center justify-between group"
        >
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">Total Patients</span>
            <div className="text-3xl font-extrabold text-stone-900 mt-1">{patients.length}</div>
            <span className="text-xs text-teal-700 font-semibold mt-1 inline-block group-hover:underline">Active records &rarr;</span>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
            <Users className="w-7 h-7" />
          </div>
        </div>

        <div 
          onClick={() => setActiveTab('appointments')}
          className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer flex items-center justify-between group"
        >
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">Today's Appointments</span>
            <div className="text-3xl font-extrabold text-stone-900 mt-1">{todayAppointments.length}</div>
            <span className="text-xs text-teal-700 font-semibold mt-1 inline-block group-hover:underline">View schedule &rarr;</span>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold">
            <Calendar className="w-7 h-7" />
          </div>
        </div>

        <div 
          onClick={() => setActiveTab('billing')}
          className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer flex items-center justify-between group"
        >
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">Total Revenue</span>
            <div className="text-3xl font-extrabold text-stone-900 mt-1">{totalRevenue} <span className="text-sm font-normal text-stone-500">{settings?.currency}</span></div>
            <span className="text-xs text-emerald-700 font-semibold mt-1 inline-block group-hover:underline">Billing logs &rarr;</span>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
            <Receipt className="w-7 h-7" />
          </div>
        </div>

        <div 
          onClick={() => setActiveTab('expenses')}
          className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer flex items-center justify-between group"
        >
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">Net Profit</span>
            <div className="text-3xl font-extrabold text-teal-800 mt-1">{netProfit} <span className="text-sm font-normal text-stone-500">{settings?.currency}</span></div>
            <span className="text-xs text-amber-700 font-semibold mt-1 inline-block group-hover:underline">Expenses: {totalExpenses} {settings?.currency}</span>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
            <Wallet className="w-7 h-7" />
          </div>
        </div>
      </div>

      {/* Chart Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-stone-900 text-lg">Financial Performance & Trends</h3>
              <p className="text-xs text-stone-500 mt-0.5">Monthly income versus operating expenses breakdown</p>
            </div>
            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-teal-50 text-teal-800">2026 Overview</span>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyRevenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0f766e" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#0f766e" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0fdf4" />
                <XAxis dataKey="month" stroke="#a8a29e" fontSize={12} tickLine={false} />
                <YAxis stroke="#a8a29e" fontSize={12} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#1c1917', borderRadius: '16px', color: '#fff', border: 'none', fontSize: '12px' }} />
                <Area type="monotone" dataKey="Income" stroke="#0f766e" strokeWidth={3} fillOpacity={1} fill="url(#colorIncome)" />
                <Area type="monotone" dataKey="Expenses" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#colorExpenses)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Today's Schedule Card */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-stone-900 text-lg">Today's Schedule</h3>
              <button 
                onClick={() => setActiveTab('appointments')}
                className="text-xs font-bold text-teal-700 hover:underline flex items-center gap-1"
              >
                <span>View All</span>
                <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
              </button>
            </div>

            <div className="space-y-3 max-h-64 overflow-y-auto">
              {todayAppointments.length === 0 ? (
                <div className="text-center py-12 text-stone-400 text-xs">
                  No appointments scheduled for today.
                </div>
              ) : (
                todayAppointments.map((app) => (
                  <div key={app.id} className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/60 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
                        {app.time}
                      </div>
                      <div>
                        <h4 className="font-bold text-stone-900">{app.patientName}</h4>
                        <span className="text-stone-500">{app.type}</span>
                      </div>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full font-bold ${
                      app.status === 'Confirmed' ? 'bg-blue-50 text-blue-700' : 'bg-emerald-50 text-emerald-700'
                    }`}>
                      {app.status}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100">
            <button
              onClick={() => setActiveTab('appointments')}
              className="w-full py-3 bg-stone-900 text-white rounded-2xl text-xs font-bold hover:bg-stone-800 transition"
            >
              Open Full Calendar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
