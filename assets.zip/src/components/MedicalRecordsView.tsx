import React, { useState } from 'react';
import { 
  FileHeart, 
  Plus, 
  Sparkles, 
  HeartPulse, 
  Stethoscope, 
  Activity, 
  Loader2, 
  Calendar, 
  User, 
  X, 
  Check 
} from 'lucide-react';
import { MedicalRecord, Patient, ClinicSettings } from '../types';

interface MedicalRecordsViewProps {
  medicalRecords: MedicalRecord[];
  patients: Patient[];
  settings: ClinicSettings;
  onAddRecord: (record: Omit<MedicalRecord, 'id'>) => void;
}

export function MedicalRecordsView({ 
  medicalRecords, 
  patients, 
  settings, 
  onAddRecord 
}: MedicalRecordsViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form state
  const [patientId, setPatientId] = useState(patients[0]?.id || '');
  const [symptoms, setSymptoms] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [treatmentNotes, setTreatmentNotes] = useState('');
  const [bp, setBp] = useState('120/80');
  const [temp, setTemp] = useState('37.0');
  const [pulse, setPulse] = useState('75');
  const [weight, setWeight] = useState('70 kg');

  // AI Assistant state
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState('');

  const selectedPatient = patients.find(p => p.id === patientId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) return;

    onAddRecord({
      patientId: selectedPatient.id,
      patientName: selectedPatient.name,
      date: new Date().toISOString().split('T')[0],
      symptoms: symptoms.trim(),
      diagnosis: diagnosis.trim(),
      treatmentNotes: treatmentNotes.trim(),
      vitals: { bp, temp, pulse, weight },
      doctorName: settings.doctorName
    });

    setSymptoms('');
    setDiagnosis('');
    setTreatmentNotes('');
    setAiAnalysisResult('');
    setIsModalOpen(false);
  };

  const handleAiClinicalAssist = async () => {
    if (!symptoms.trim()) return;
    setIsAiAnalyzing(true);
    setAiAnalysisResult('');

    try {
      const res = await fetch('/api/ai/clinical-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symptoms,
          patientAge: selectedPatient?.age,
          patientGender: selectedPatient?.gender,
          medicalHistory: selectedPatient?.medicalHistory,
          aiProvider: settings.aiProvider,
          aiApiKey: settings.aiApiKey,
          aiCustomEndpoint: settings.aiCustomEndpoint,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setAiAnalysisResult(data.result);
    } catch (err: any) {
      setAiAnalysisResult('Sorry, an error occurred while connecting to the AI Clinical Assistant.');
    } finally {
      setIsAiAnalyzing(false);
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Medical Records & Diagnosis</h2>
          <p className="text-sm text-stone-500 mt-1">Record examination details, vital signs, and patient medical diagnosis powered by AI.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-teal-700 text-white px-5 py-3 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
        >
          <Plus className="w-4 h-4 text-teal-200" />
          <span>New Medical Record</span>
        </button>
      </div>

      {/* Records List */}
      <div className="grid grid-cols-1 gap-5">
        {medicalRecords.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-stone-200/80 text-stone-400 text-sm">
            No medical records registered yet.
          </div>
        ) : (
          medicalRecords.map((record) => (
            <div key={record.id} className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs space-y-4 hover:border-teal-500/50 transition">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-stone-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
                    <Stethoscope className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-stone-900 text-lg">{record.patientName}</h3>
                    <p className="text-xs text-stone-500">{record.doctorName} • {record.date}</p>
                  </div>
                </div>

                {/* Vitals badge */}
                <div className="flex items-center gap-2 flex-wrap text-xs font-semibold">
                  <span className="px-3 py-1.5 rounded-xl bg-stone-100 text-stone-700">BP: {record.vitals.bp}</span>
                  <span className="px-3 py-1.5 rounded-xl bg-stone-100 text-stone-700">Temp: {record.vitals.temp}°C</span>
                  <span className="px-3 py-1.5 rounded-xl bg-stone-100 text-stone-700">Pulse: {record.vitals.pulse} bpm</span>
                  <span className="px-3 py-1.5 rounded-xl bg-stone-100 text-stone-700">Weight: {record.vitals.weight}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200/60 space-y-1">
                  <span className="text-xs font-bold text-stone-500 uppercase tracking-wider block">Symptoms & Complaints</span>
                  <p className="text-stone-800 leading-relaxed">{record.symptoms}</p>
                </div>
                <div className="bg-teal-50/60 p-4 rounded-2xl border border-teal-100 space-y-1">
                  <span className="text-xs font-bold text-teal-800 uppercase tracking-wider block">Medical Diagnosis</span>
                  <p className="text-stone-900 font-bold leading-relaxed">{record.diagnosis}</p>
                </div>
              </div>

              {record.treatmentNotes && (
                <div className="text-xs text-stone-600 bg-stone-50 p-3.5 rounded-xl border border-stone-100">
                  <span className="font-bold text-stone-800">Treatment Plan & Notes: </span>
                  <span>{record.treatmentNotes}</span>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden border border-stone-200 my-8">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-stone-900 text-lg">Add New Medical Examination</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Select Patient</label>
                <select
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                >
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.phone})</option>
                  ))}
                </select>
              </div>

              {/* Vitals Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-stone-50 p-4 rounded-2xl border border-stone-200">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Blood Pressure</label>
                  <input
                    type="text"
                    value={bp}
                    onChange={(e) => setBp(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Temperature (°C)</label>
                  <input
                    type="text"
                    value={temp}
                    onChange={(e) => setTemp(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Pulse (bpm)</label>
                  <input
                    type="text"
                    value={pulse}
                    onChange={(e) => setPulse(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Weight</label>
                  <input
                    type="text"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-stone-700">Symptoms & Patient Complaints</label>
                  <button
                    type="button"
                    onClick={handleAiClinicalAssist}
                    disabled={isAiAnalyzing || !symptoms.trim()}
                    className="flex items-center gap-1.5 bg-teal-50 text-teal-800 hover:bg-teal-100 px-3 py-1 rounded-xl text-xs font-bold transition border border-teal-200 disabled:opacity-50"
                  >
                    {isAiAnalyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-teal-600" />}
                    <span>AI Clinical Assist</span>
                  </button>
                </div>
                <textarea
                  rows={3}
                  required
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  placeholder="Enter patient's reported symptoms..."
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              {aiAnalysisResult && (
                <div className="bg-teal-50/80 p-4 rounded-2xl border border-teal-200 text-teal-900 space-y-2 animate-in fade-in">
                  <div className="flex items-center gap-2 font-bold">
                    <Sparkles className="w-4 h-4 text-teal-700" />
                    <span>AI Clinical Suggestions & Differential Diagnosis</span>
                  </div>
                  <p className="text-xs leading-relaxed text-teal-800 whitespace-pre-line">{aiAnalysisResult}</p>
                </div>
              )}

              <div>
                <label className="block font-bold text-stone-700 mb-1">Medical Diagnosis</label>
                <input
                  type="text"
                  required
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  placeholder="e.g. Acute Pharyngitis"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Treatment Plan & Physician Notes</label>
                <textarea
                  rows={2}
                  value={treatmentNotes}
                  onChange={(e) => setTreatmentNotes(e.target.value)}
                  placeholder="Medication instructions, lifestyle changes, follow-up..."
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 text-white hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  Save Medical Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
