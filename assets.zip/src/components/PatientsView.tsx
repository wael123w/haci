import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Phone, 
  MapPin, 
  Calendar, 
  FileText, 
  X, 
  Check, 
  UserPlus, 
  HeartPulse 
} from 'lucide-react';
import { Patient, MedicalRecord, ClinicSettings } from '../types';

interface PatientsViewProps {
  patients: Patient[];
  medicalRecords: MedicalRecord[];
  onAddPatient: (patient: Omit<Patient, 'id' | 'createdAt'>) => void;
  onSelectPatientForRecord?: (patientId: string) => void;
  settings?: ClinicSettings;
}

export function PatientsView({ patients, medicalRecords, onAddPatient, settings }: PatientsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [address, setAddress] = useState('');
  const [bloodGroup, setBloodGroup] = useState('O+');
  const [medicalHistory, setMedicalHistory] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !age) return;

    onAddPatient({
      name: name.trim(),
      phone: phone.trim(),
      age: Number(age),
      gender,
      address: address.trim() || 'New York',
      bloodGroup,
      medicalHistory: medicalHistory.trim() || 'No prior chronic medical history'
    });

    setName('');
    setPhone('');
    setAge('');
    setAddress('');
    setMedicalHistory('');
    setIsModalOpen(false);
  };

  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.phone.includes(searchTerm)
  );

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Patients Management</h2>
          <p className="text-sm text-stone-500 mt-1">Comprehensive database for all clinic patients with medical history and follow-up files.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-teal-700 text-white px-5 py-3 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
        >
          <UserPlus className="w-4 h-4 text-teal-200" />
          <span>Add New Patient</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200/80 shadow-xs flex items-center gap-3">
        <Search className="w-5 h-5 text-stone-400 ml-2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by phone number or patient name..."
          className="w-full bg-transparent text-sm focus:outline-hidden text-stone-800 placeholder-stone-400"
        />
      </div>

      {/* Patients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredPatients.length === 0 ? (
          <div className="col-span-full text-center py-16 text-stone-400 text-sm bg-white rounded-3xl border border-stone-200/80">
            No matching patients found.
          </div>
        ) : (
          filteredPatients.map((patient) => {
            const patientRecords = medicalRecords.filter(r => r.patientId === patient.id);
            return (
              <div
                key={patient.id}
                onClick={() => setSelectedPatient(patient)}
                className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div>
                      <h3 className="font-bold text-stone-900 text-lg group-hover:text-teal-700 transition">
                        {patient.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-800">
                          {patient.gender} • {patient.age} yrs
                        </span>
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-red-50 text-red-700">
                          {patient.bloodGroup}
                        </span>
                      </div>
                    </div>
                    <div className="w-10 h-10 rounded-2xl bg-stone-100 text-stone-600 flex items-center justify-center font-bold text-sm">
                      {patient.name.charAt(0)}
                    </div>
                  </div>

                  <div className="space-y-2 text-xs text-stone-600 mb-4">
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-stone-400 shrink-0" />
                      <span>{patient.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-stone-400 shrink-0" />
                      <span className="truncate">{patient.address}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-100 flex items-center justify-between text-xs">
                  <span className="text-stone-500 flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5" />
                    <span>{patientRecords.length} medical records</span>
                  </span>
                  <span className="font-bold text-teal-700 group-hover:underline">View Profile &rarr;</span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Patient Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden border border-stone-200 animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-stone-900 text-lg">Register New Patient</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="555-0100"
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Age</label>
                  <input
                    type="number"
                    required
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    placeholder="30"
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Gender</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Blood Group</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  >
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. Manhattan, New York"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Medical History & Chronic Conditions</label>
                <textarea
                  rows={3}
                  value={medicalHistory}
                  onChange={(e) => setMedicalHistory(e.target.value)}
                  placeholder="Allergies, prior surgeries, chronic diseases..."
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 text-white hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  Save Patient
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Patient Detail Modal */}
      {selectedPatient && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden border border-stone-200 p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-stone-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-teal-700 text-white flex items-center justify-center font-bold text-lg">
                  {selectedPatient.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-xl">{selectedPatient.name}</h3>
                  <p className="text-xs text-stone-500">Registered on: {selectedPatient.createdAt}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPatient(null)}
                className="w-9 h-9 rounded-xl bg-stone-100 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200">
                <span className="text-stone-500 block mb-1">Age & Gender</span>
                <span className="font-bold text-stone-900">{selectedPatient.age} yrs • {selectedPatient.gender}</span>
              </div>
              <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200">
                <span className="text-stone-500 block mb-1">Phone</span>
                <span className="font-bold text-stone-900">{selectedPatient.phone}</span>
              </div>
              <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200">
                <span className="text-stone-500 block mb-1">Blood Group</span>
                <span className="font-bold text-red-600">{selectedPatient.bloodGroup}</span>
              </div>
              <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200">
                <span className="text-stone-500 block mb-1">Address</span>
                <span className="font-bold text-stone-900 truncate">{selectedPatient.address}</span>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <h4 className="font-bold text-stone-900 text-sm">Medical History & Allergies</h4>
              <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-100 text-amber-900">
                {selectedPatient.medicalHistory}
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <h4 className="font-bold text-stone-900 text-sm">Patient's Medical Records & Visits</h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {medicalRecords.filter(r => r.patientId === selectedPatient.id).length === 0 ? (
                  <p className="text-xs text-stone-400 py-4 text-center">No recorded visits for this patient yet.</p>
                ) : (
                  medicalRecords.filter(r => r.patientId === selectedPatient.id).map(rec => (
                    <div key={rec.id} className="p-3 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-1">
                      <div className="flex items-center justify-between font-bold text-stone-900">
                        <span>Diagnosis: {rec.diagnosis}</span>
                        <span className="text-stone-500">{rec.date}</span>
                      </div>
                      <p className="text-stone-600">Treatment: {rec.treatmentNotes}</p>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-stone-100">
              <button
                onClick={() => setSelectedPatient(null)}
                className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-stone-900 text-white hover:bg-stone-800 transition"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
