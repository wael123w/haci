import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  Plus, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Filter, 
  User, 
  Phone, 
  X, 
  Check,
  Search
} from 'lucide-react';
import { Appointment, Patient, ClinicSettings } from '../types';

interface AppointmentsViewProps {
  appointments: Appointment[];
  patients: Patient[];
  settings: ClinicSettings;
  onAddAppointment: (appointment: Omit<Appointment, 'id'>) => void;
  onUpdateStatus: (id: string, status: Appointment['status']) => void;
}

export function AppointmentsView({ 
  appointments, 
  patients, 
  settings, 
  onAddAppointment, 
  onUpdateStatus 
}: AppointmentsViewProps) {
  const [filterDate, setFilterDate] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const doctorsList = settings.doctors && settings.doctors.length > 0
    ? settings.doctors
    : [{ id: 'default', name: settings.doctorName, specialty: settings.specialty, room: 'Room 101', phone: settings.phone }];

  // New Appointment Form
  const [patientId, setPatientId] = useState(patients[0]?.id || '');
  const [patientSearchQuery, setPatientSearchQuery] = useState('');
  const [isPatientDropdownOpen, setIsPatientDropdownOpen] = useState(false);

  const selectedPatient = patients.find(p => p.id === patientId);
  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(patientSearchQuery.toLowerCase()) ||
    p.id.toLowerCase().includes(patientSearchQuery.toLowerCase()) ||
    p.phone.includes(patientSearchQuery)
  );

  const [selectedDoctorName, setSelectedDoctorName] = useState(doctorsList[0]?.name || settings.doctorName);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('10:00');
  const [type, setType] = useState<Appointment['type']>('New Consultation');
  const [notes, setNotes] = useState('');
  const [price, setPrice] = useState(settings.consultationFee.toString());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    const isCancelled = (status: string) => status === 'Cancelled' || status === 'ملغى' || status === 'ملغي';
    const conflict = appointments.find(a =>
      a.doctorName === selectedDoctorName &&
      a.date === date &&
      a.time === time &&
      !isCancelled(a.status)
    );
    if (conflict) {
      alert(`This doctor already has an appointment with ${conflict.patientName} at ${time} on ${date}. Please choose a different time.`);
      return;
    }

    onAddAppointment({
      patientId: patient.id,
      patientName: patient.name,
      doctorName: selectedDoctorName,
      date,
      time,
      status: 'Confirmed',
      type,
      notes: notes.trim(),
      price: Number(price) || settings.consultationFee
    });

    setNotes('');
    setIsModalOpen(false);
  };

  const filteredAppointments = appointments.filter(a => {
    const matchDate = filterDate ? a.date === filterDate : true;
    const matchStatus = filterStatus === 'All' ? true : a.status === filterStatus;
    return matchDate && matchStatus;
  });

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Appointments & Calendar</h2>
          <p className="text-sm text-stone-500 mt-1">Book, update, and track daily patient appointments with ease.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-teal-700 text-white px-5 py-3 rounded-2xl text-sm font-bold hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
        >
          <Plus className="w-4 h-4 text-teal-200" />
          <span>Book New Appointment</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Calendar className="w-5 h-5 text-stone-400" />
          <input
            type="date"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
            className="bg-stone-50 border border-stone-200 rounded-2xl px-4 py-2 text-sm focus:outline-hidden focus:border-teal-600 transition"
          />
          {filterDate && (
            <button
              onClick={() => setFilterDate('')}
              className="text-xs text-teal-700 font-semibold hover:underline"
            >
              Show All Days
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          <Filter className="w-4 h-4 text-stone-400 ml-1" />
          {['All', 'Confirmed', 'Completed', 'Pending', 'Cancelled'].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                filterStatus === status
                  ? 'bg-teal-700 text-white shadow-sm'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Appointments List */}
      <div className="bg-white rounded-3xl border border-stone-200/80 shadow-xs overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex items-center justify-between">
          <h3 className="font-bold text-stone-900">Scheduled Appointments</h3>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-stone-100 text-stone-600">
            {filteredAppointments.length} Appointments
          </span>
        </div>

        <div className="divide-y divide-stone-100">
          {filteredAppointments.length === 0 ? (
            <div className="text-center py-16 text-stone-400 text-sm">
              No appointments matching the selected filters.
            </div>
          ) : (
            filteredAppointments.map((app) => (
              <div key={app.id} className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-stone-50/60 transition">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-700 flex flex-col items-center justify-center font-extrabold shrink-0 border border-teal-100">
                    <span className="text-sm">{app.time}</span>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <h4 className="font-bold text-stone-900 text-base">{app.patientName}</h4>
                      <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-stone-100 text-stone-700">
                        {app.type}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-stone-500">
                      <span>Doctor: <strong className="text-stone-700">{app.doctorName}</strong></span>
                      <span>Date: <strong className="text-stone-700">{app.date}</strong></span>
                    </div>
                    {app.notes && <p className="text-xs text-stone-500 italic">"{app.notes}"</p>}
                  </div>
                </div>

                <div className="flex items-center gap-3 justify-end">
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                    app.status === 'Confirmed' || app.status === 'مؤكد'
                      ? 'bg-blue-50 text-blue-700 border border-blue-100'
                      : app.status === 'Completed' || app.status === 'مكتمل'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                      : app.status === 'Pending' || app.status === 'قيد الانتظار'
                      ? 'bg-amber-50 text-amber-700 border border-amber-100'
                      : 'bg-red-50 text-red-700 border border-red-100'
                  }`}>
                    {app.status}
                  </span>

                  <div className="flex items-center gap-1.5 border-l border-stone-200 pl-3">
                    {app.status !== 'Completed' && app.status !== 'مكتمل' && (
                      <button
                        onClick={() => onUpdateStatus(app.id, 'Completed')}
                        className="p-2 rounded-xl bg-stone-100 hover:bg-emerald-50 hover:text-emerald-700 text-stone-600 transition"
                        title="Mark as Completed"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                    {app.status !== 'Cancelled' && app.status !== 'ملغي' && (
                      <button
                        onClick={() => onUpdateStatus(app.id, 'Cancelled')}
                        className="p-2 rounded-xl bg-stone-100 hover:bg-red-50 hover:text-red-700 text-stone-600 transition"
                        title="Cancel Appointment"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* New Appointment Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden border border-stone-200 animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-stone-900 text-lg">Book New Appointment</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-stone-200/60 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Select Patient</label>
                <select
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                >
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.phone})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Doctor / Specialist</label>
                  <select
                    value={selectedDoctorName}
                    onChange={(e) => setSelectedDoctorName(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  >
                    {doctorsList.map(doc => (
                      <option key={doc.id} value={doc.name}>{doc.name} ({doc.specialty})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Appointment Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  >
                    <option value="New Consultation">New Consultation</option>
                    <option value="Follow-up">Follow-up</option>
                    <option value="Emergency">Emergency</option>
                    <option value="Procedure">Procedure</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Time</label>
                  <input
                    type="time"
                    required
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Fee ({settings.currency})</label>
                  <input
                    type="number"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Notes (Optional)</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Special instructions or symptoms..."
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm focus:outline-hidden focus:border-teal-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-sm font-semibold bg-stone-100 text-stone-600 hover:bg-stone-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 text-white hover:bg-teal-800 transition shadow-md shadow-teal-700/20"
                >
                  Confirm Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
