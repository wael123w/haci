// Talks to the real backend API
// Backend URL: https://liveapp.buzeasy.net/backend-php/api/

const API_BASE_URL = "https://liveapp.buzeasy.net/backend-php/api";

const TOKEN_KEY = "hakeem_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(
  method: string,
  path: string,
  body?: unknown
): Promise<T> {

  const token = getToken();

  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,

    headers: {
      "Content-Type": "application/json",

      ...(token
        ? {
            Authorization: `Bearer ${token}`,
          }
        : {}),
    },

    body:
      body !== undefined
        ? JSON.stringify(body)
        : undefined,
  });


  if (res.status === 401) {
    setToken(null);
  }


  let data: any = null;

  try {
    data = await res.json();
  } catch {
    // Empty response
  }


  if (!res.ok) {
    throw new ApiError(
      data?.error || `Request failed (${res.status})`,
      res.status
    );
  }


  return data as T;
}


export const api = {

  login: (
    username: string,
    password: string
  ) =>
    request<{ token: string; user: any }>(
      "POST",
      "/auth/login",
      {
        username,
        password,
      }
    ),


  publicBranding: () =>
    request<any>(
      "GET",
      "/public/branding"
    ),


  bootstrap: () =>
    request<any>(
      "GET",
      "/bootstrap"
    ),


  saveSettings: (settings: any) =>
    request<any>(
      "PUT",
      "/settings",
      settings
    ),


  addPatient: (patient: any) =>
    request<any>(
      "POST",
      "/patients",
      patient
    ),


  addAppointment: (appointment: any) =>
    request<any>(
      "POST",
      "/appointments",
      appointment
    ),


  updateAppointmentStatus: (
    id: string,
    status: string
  ) =>
    request<{ ok: true }>(
      "PATCH",
      `/appointments/${id}/status`,
      { status }
    ),


  addMedicalRecord: (record: any) =>
    request<any>(
      "POST",
      "/medical-records",
      record
    ),


  addPrescription: (prescription: any) =>
    request<any>(
      "POST",
      "/prescriptions",
      prescription
    ),


  addInvoice: (invoice: any) =>
    request<any>(
      "POST",
      "/invoices",
      invoice
    ),


  updateInvoiceStatus: (
    id: string,
    status: string,
    paidAmount: number
  ) =>
    request<{ ok: true }>(
      "PATCH",
      `/invoices/${id}/status`,
      {
        status,
        paidAmount,
      }
    ),


  addExpense: (expense: any) =>
    request<any>(
      "POST",
      "/expenses",
      expense
    ),


  deleteExpense: (id: string) =>
    request<{ ok: true }>(
      "DELETE",
      `/expenses/${id}`
    ),


  addService: (service: any) =>
    request<any>(
      "POST",
      "/services",
      service
    ),


  deleteService: (id: string) =>
    request<{ ok: true }>(
      "DELETE",
      `/services/${id}`
    ),


  addMedicine: (medicine: any) =>
    request<any>(
      "POST",
      "/medicines",
      medicine
    ),


  deleteMedicine: (id: string) =>
    request<{ ok: true }>(
      "DELETE",
      `/medicines/${id}`
    ),
};


export { ApiError };