export type ActiveTab = 
  | 'dashboard' 
  | 'patients' 
  | 'appointments' 
  | 'records' 
  | 'prescriptions' 
  | 'billing' 
  | 'expenses' 
  | 'services' 
  | 'medicines' 
  | 'settings';

export interface Patient {
  id: string;
  name: string;
  phone: string;
  age: number;
  gender: string;
  address: string;
  bloodGroup: string;
  medicalHistory: string;
  createdAt: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  doctorName: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  status: string;
  type: string;
  notes?: string;
  price: number;
}

export interface Vitals {
  bp: string; // e.g., 120/80
  temp: string; // e.g., 37.2
  pulse: string; // e.g., 78
  weight: string; // e.g., 75 kg
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  symptoms: string;
  diagnosis: string;
  treatmentNotes: string;
  vitals: Vitals;
  doctorName: string;
}

export interface PrescriptionItem {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  notes?: string;
}

export interface PrescriptionTest {
  name: string;
  notes?: string;
}

export interface Prescription {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  diagnosis: string;
  medications: PrescriptionItem[];
  tests: PrescriptionTest[];
  advice: string;
  doctorName: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  amount: number;
}

export interface Invoice {
  id: string;
  patientId: string;
  patientName: string;
  items: InvoiceItem[];
  totalAmount: number;
  paidAmount: number;
  status: string;
  date: string;
  paymentMethod: string;
}

export interface Expense {
  id: string;
  title: string;
  category: string;
  amount: number;
  date: string;
  notes?: string;
}

export interface Service {
  id: string;
  name: string;
  category: string;
  price: number;
  durationMinutes: number;
}

export interface Medicine {
  id: string;
  name: string;
  form: string;
  concentration: string;
  stock: number;
  price: number;
}

export interface UserPermissions {
  dashboard: boolean;
  patients: boolean;
  appointments: boolean;
  records: boolean;
  prescriptions: boolean;
  billing: boolean;
  expenses: boolean;
  services: boolean;
  medicines: boolean;
  settings: boolean;
}

export interface UserAccount {
  id: string;
  username: string;
  // Never the real hash on the client: empty when read from the server
  // (see server/settingsStore.ts stripPasswords), and only ever holds a
  // plaintext value here when the admin is actively setting/resetting one
  // (sent once over HTTPS to PUT /api/settings, which hashes it server-side).
  password?: string;
  name: string;
  role: 'doctor' | 'receptionist' | 'admin';
  specialty?: string;
  permissions: UserPermissions;
}

export interface Department {
  id: string;
  name: string;
  description: string;
  headDoctor: string;
  room: string;
  status: 'active' | 'inactive';
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  email?: string;
  room?: string;
  workingHours?: string;
}

export interface ClinicSettings {
  clinicName: string;
  doctorName: string;
  specialty: string;
  phone: string;
  email: string;
  address: string;
  workingHours: string;
  currency: string;
  consultationFee: number;
  supportUrl: string;
  language: string; // 'ar', 'en', or custom
  clinicLogo?: string;
  clinicImage?: string;
  loginBackground?: string;
  siteFavicon?: string;
  departments?: Department[];
  doctors?: Doctor[];
  aiProvider?: 'gemini' | 'openai' | 'anthropic' | 'custom';
  aiApiKey?: string;
  aiCustomEndpoint?: string;
  customLanguages?: Array<{ code: string; name: string; translations: Record<string, string> }>;
  darkMode?: boolean;
  users: UserAccount[];
}
