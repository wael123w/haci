import { Patient, Appointment, MedicalRecord, Prescription, Invoice, Expense, Service, Medicine, ClinicSettings } from './types';

export const initialSettings: ClinicSettings = {
  clinicName: 'Apex Specialized Medical Center',
  doctorName: 'Dr. Adam Hakeem',
  specialty: 'General Practice',
  phone: '+1 (555) 234-5678',
  email: 'info@apexmedicalcenter.com',
  address: '123 Medical Plaza, Suite 400, New York, NY',
  workingHours: 'Mon - Sat: 9:00 AM - 9:00 PM',
  currency: '$',
  consultationFee: 150,
  supportUrl: 'https://wa.me/15552345678',
  language: 'en',
  // Left empty on purpose (no third-party/Unsplash URLs): those links can
  // break or violate usage terms once shipped as a commercial product.
  // The buyer uploads their own clinic logo, cover image, login background,
  // and favicon from Settings > Branding after installing.
  clinicLogo: '',
  clinicImage: '',
  loginBackground: '',
  siteFavicon: '',
  aiProvider: 'gemini',
  aiApiKey: '',
  aiCustomEndpoint: '',
  departments: [
    { id: 'dept-1', name: 'General Medicine Dept', description: 'Comprehensive examination and acute/chronic disease management', headDoctor: 'Dr. Adam Hakeem', room: 'Room 101', status: 'active' },
    { id: 'dept-2', name: 'Dental Care Dept', description: 'Dental treatment, aesthetics, and oral surgery', headDoctor: 'Dr. Sarah Khalid', room: 'Room 102', status: 'active' },
    { id: 'dept-3', name: 'Pediatrics Dept', description: 'Newborn care, child growth tracking, and vaccinations', headDoctor: 'Dr. Michael Rashid', room: 'Room 103', status: 'active' }
  ],
  doctors: [
    { id: 'doc-1', name: 'Dr. Adam Hakeem', specialty: 'General Practice', phone: '+1 (555) 234-5678', email: 'ahmad@apexmedical.com', room: 'Room 101', workingHours: '9:00 AM - 9:00 PM' },
    { id: 'doc-2', name: 'Dr. Sarah Khalid', specialty: 'Dental Surgery', phone: '+1 (555) 345-6789', email: 'sara@apexmedical.com', room: 'Room 102', workingHours: '10:00 AM - 6:00 PM' },
    { id: 'doc-3', name: 'Dr. Michael Rashid', specialty: 'Pediatrics', phone: '+1 (555) 456-7890', email: 'michael@apexmedical.com', room: 'Room 103', workingHours: '8:00 AM - 4:00 PM' }
  ],
  customLanguages: [],
  darkMode: false,
  users: [
    { 
      // Demo password is "123". Stored as SHA-256("admin:123") — never plain text.
      // See src/utils/auth.ts for the hashing scheme.
      id: 'u-1', 
      username: 'admin', 
      password: 'f6bd2d1a9a2798aa5b2a000d477587b65aaac9a417064d91ed2bcd8714bbba89', 
      name: 'System Administrator', 
      role: 'admin',
      permissions: { dashboard: true, patients: true, appointments: true, records: true, prescriptions: true, billing: true, expenses: true, services: true, medicines: true, settings: true }
    },
    { 
      // Demo password is "123". Stored as SHA-256("doctor:123").
      id: 'u-2', 
      username: 'doctor', 
      password: '07c1c13bdc013ca49592fd01929e138a2599f1750f1de9491574230c368c0b01', 
      name: 'Dr. Adam Hakeem', 
      role: 'doctor', 
      specialty: 'General',
      permissions: { dashboard: true, patients: true, appointments: true, records: true, prescriptions: true, billing: false, expenses: false, services: true, medicines: true, settings: false }
    },
    { 
      // Demo password is "123". Stored as SHA-256("reception:123").
      id: 'u-3', 
      username: 'reception', 
      password: '066dea97554f2255fd95306d5b8b25b92ff30d81ee9cc6346e1157dc4b784f68', 
      name: 'Sarah Smith (Reception)', 
      role: 'receptionist',
      permissions: { dashboard: true, patients: true, appointments: true, records: false, prescriptions: false, billing: true, expenses: true, services: false, medicines: false, settings: false }
    }
  ]
};

export const initialPatients: Patient[] = [
  {
    id: 'p-1',
    name: 'Johnathan Smith',
    phone: '555-011-2233',
    age: 34,
    gender: 'Male',
    address: 'New York, Manhattan',
    bloodGroup: 'O+',
    medicalHistory: 'Penicillin allergy, no prior chronic diseases.',
    createdAt: '2026-06-01'
  },
  {
    id: 'p-2',
    name: 'Emily Davis',
    phone: '555-222-3344',
    age: 28,
    gender: 'Female',
    address: 'New York, Brooklyn',
    bloodGroup: 'A+',
    medicalHistory: 'Mild hypertension history.',
    createdAt: '2026-06-05'
  },
  {
    id: 'p-3',
    name: 'Robert Johnson',
    phone: '555-333-4455',
    age: 45,
    gender: 'Male',
    address: 'New York, Queens',
    bloodGroup: 'B-',
    medicalHistory: 'Type 2 Diabetes mellitus.',
    createdAt: '2026-06-10'
  },
  {
    id: 'p-4',
    name: 'Sophia Williams',
    phone: '555-444-5566',
    age: 29,
    gender: 'Female',
    address: 'New York, Bronx',
    bloodGroup: 'AB+',
    medicalHistory: 'Healthy and fit.',
    createdAt: '2026-06-12'
  }
];

export const initialAppointments: Appointment[] = [
  {
    id: 'a-1',
    patientId: 'p-1',
    patientName: 'Johnathan Smith',
    doctorName: 'Dr. Adam Hakeem',
    date: '2026-07-27',
    time: '10:00',
    status: 'Confirmed',
    type: 'New Consultation',
    notes: 'Complaining of cold symptoms and persistent cough',
    price: 150
  },
  {
    id: 'a-2',
    patientId: 'p-2',
    patientName: 'Emily Davis',
    doctorName: 'Dr. Adam Hakeem',
    date: '2026-07-27',
    time: '11:30',
    status: 'Completed',
    type: 'Follow-up',
    notes: 'Blood pressure routine checkup',
    price: 150
  },
  {
    id: 'a-3',
    patientId: 'p-3',
    patientName: 'Robert Johnson',
    doctorName: 'Dr. Adam Hakeem',
    date: '2026-07-28',
    time: '09:00',
    status: 'Pending',
    type: 'Follow-up',
    notes: 'Diabetic routine review',
    price: 150
  },
  {
    id: 'a-4',
    patientId: 'p-4',
    patientName: 'Sophia Williams',
    doctorName: 'Dr. Adam Hakeem',
    date: '2026-07-28',
    time: '12:00',
    status: 'Confirmed',
    type: 'Emergency',
    notes: 'Severe throat pain',
    price: 200
  }
];

export const initialMedicalRecords: MedicalRecord[] = [
  {
    id: 'r-1',
    patientId: 'p-2',
    patientName: 'Emily Davis',
    date: '2026-07-27',
    symptoms: 'Mild headache with elevated blood pressure reading 140/90',
    diagnosis: 'Stage 1 Essential Hypertension',
    treatmentNotes: 'Prescribed anti-hypertensive medication, advised rest and low sodium diet.',
    vitals: {
      bp: '140/90',
      temp: '37.0°C',
      pulse: '82 bpm',
      weight: '68 kg'
    },
    doctorName: 'Dr. Adam Hakeem'
  }
];

export const initialPrescriptions: Prescription[] = [
  {
    id: 'pr-1',
    patientId: 'p-2',
    patientName: 'Emily Davis',
    date: '2026-07-27',
    diagnosis: 'Hypertension',
    medications: [
      { name: 'Concor', dosage: '5 mg', frequency: 'Once daily in the morning', duration: '30 days', notes: 'Take after breakfast' },
      { name: 'Panadol', dosage: '500 mg', frequency: 'As needed for headache', duration: '5 days' }
    ],
    tests: [
      { name: 'Kidney Function Test (Creatinine & Urea)' },
      { name: 'Electrocardiogram (ECG)' }
    ],
    advice: 'Reduce salt intake, drink plenty of water, and engage in light walking exercise.',
    doctorName: 'Dr. Adam Hakeem'
  }
];

export const initialInvoices: Invoice[] = [
  {
    id: 'inv-1',
    patientId: 'p-2',
    patientName: 'Emily Davis',
    items: [
      { id: 'i-1', description: 'Medical Consultation', amount: 150 },
      { id: 'i-2', description: 'BP & Vitals Check', amount: 50 }
    ],
    totalAmount: 200,
    paidAmount: 200,
    status: 'Paid',
    date: '2026-07-27',
    paymentMethod: 'Cash'
  },
  {
    id: 'inv-2',
    patientId: 'p-1',
    patientName: 'Johnathan Smith',
    items: [
      { id: 'i-3', description: 'New Patient Consultation', amount: 150 }
    ],
    totalAmount: 150,
    paidAmount: 0,
    status: 'Pending',
    date: '2026-07-27',
    paymentMethod: 'Cash'
  }
];

export const initialExpenses: Expense[] = [
  {
    id: 'exp-1',
    title: 'Clinic Monthly Rent',
    category: 'Rent',
    amount: 5000,
    date: '2026-07-01',
    notes: 'July rent payment'
  },
  {
    id: 'exp-2',
    title: 'Medical Supplies & Masks',
    category: 'Medical Consumables',
    amount: 1200,
    date: '2026-07-10',
    notes: 'Gloves, masks, and sanitizers'
  },
  {
    id: 'exp-3',
    title: 'Electricity & Internet Bill',
    category: 'Utilities',
    amount: 850,
    date: '2026-07-15',
    notes: 'Monthly utility billing'
  }
];

export const initialServices: Service[] = [
  { id: 's-1', name: 'New Consultation', category: 'Consultations', price: 150, durationMinutes: 30 },
  { id: 's-2', name: 'Follow-up Consultation', category: 'Consultations', price: 100, durationMinutes: 20 },
  { id: 's-3', name: 'Emergency Visit', category: 'Emergency', price: 250, durationMinutes: 45 },
  { id: 's-4', name: 'Routine Checkup', category: 'Follow-up', price: 100, durationMinutes: 15 },
  { id: 's-5', name: 'ECG Test', category: 'Examinations', price: 200, durationMinutes: 20 }
];

export const initialMedicines: Medicine[] = [
  { id: 'm-1', name: 'Panadol', form: 'Tablets', concentration: '500 mg', stock: 150, price: 15 },
  { id: 'm-2', name: 'Augmentin', form: 'Tablets', concentration: '1g', stock: 80, price: 45 },
  { id: 'm-3', name: 'Concor', form: 'Tablets', concentration: '5 mg', stock: 60, price: 35 },
  { id: 'm-4', name: 'Brufen', form: 'Syrup', concentration: '100 mg/5ml', stock: 40, price: 20 },
  { id: 'm-5', name: 'Omeprazole', form: 'Capsules', concentration: '20 mg', stock: 95, price: 30 }
];
