import React, { useState, useEffect } from 'react';
import { ActiveTab, Patient, Appointment, MedicalRecord, Prescription, Invoice, Expense, Service, Medicine, ClinicSettings, UserAccount } from './types';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { PatientsView } from './components/PatientsView';
import { AppointmentsView } from './components/AppointmentsView';
import { MedicalRecordsView } from './components/MedicalRecordsView';
import { PrescriptionsView } from './components/PrescriptionsView';
import { BillingView } from './components/BillingView';
import { ExpensesView } from './components/ExpensesView';
import { ServicesView } from './components/ServicesView';
import { MedicinesView } from './components/MedicinesView';
import { SettingsView } from './components/SettingsView';
import { LoginView } from './components/LoginView';
import { api, getToken, setToken } from './utils/api';

const emptySettings: ClinicSettings = {
  clinicName: '', doctorName: '', specialty: '', phone: '', email: '', address: '',
  workingHours: '', currency: '', consultationFee: 0, supportUrl: '', language: 'ar',
  users: [],
};

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  const [currentUser, setCurrentUserState] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('hakeem_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Wraps setCurrentUser so login/logout also manage the auth token and
  // the small (password-free) user record we keep in localStorage purely
  // so a page refresh doesn't bounce a logged-in user back to the login
  // screen before the bootstrap fetch below confirms the session.
  const setCurrentUser = (user: UserAccount | null) => {
    setCurrentUserState(user);
    if (user) {
      localStorage.setItem('hakeem_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('hakeem_current_user');
      setToken(null);
    }
  };

  const [settings, setSettings] = useState<ClinicSettings>(emptySettings);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [loadError, setLoadError] = useState('');

  // Loads everything from the server in one request whenever there's a
  // logged-in user with a token. All clinic data now lives in MySQL — see
  // server/routes.ts (GET /api/bootstrap) — nothing is read from
  // localStorage anymore except the auth token and this small user record.
  // Before anyone logs in there's no token yet to call the full bootstrap
  // endpoint, so pull just the public branding fields (clinic name/logo/
  // background) for the login screen — see GET /api/public/branding.
  useEffect(() => {
    if (currentUser) return;
    let cancelled = false;
    api.publicBranding()
      .then((branding) => {
        if (!cancelled) setSettings(prev => ({ ...prev, ...branding }));
      })
      .catch(() => { /* login screen still works with default branding */ });
    return () => { cancelled = true; };
  }, [currentUser]);

  useEffect(() => {
    if (!currentUser || !getToken()) {
      setIsLoadingData(false);
      return;
    }
    let cancelled = false;
    setIsLoadingData(true);
    setLoadError('');
    api.bootstrap()
      .then((data) => {
        if (cancelled) return;
        setSettings(data.settings);
        setPatients(data.patients);
        setAppointments(data.appointments);
        setMedicalRecords(data.medicalRecords);
        setPrescriptions(data.prescriptions);
        setInvoices(data.invoices);
        setExpenses(data.expenses);
        setServices(data.services);
        setMedicines(data.medicines);
      })
      .catch((err) => {
        if (cancelled) return;
        // A missing/expired token means the server already rejected us —
        // send the user back to the login screen instead of showing an error.
        if (!getToken()) {
          setCurrentUser(null);
        } else {
          setLoadError(err?.message || 'تعذر الاتصال بالخادم');
        }
      })
      .finally(() => {
        if (!cancelled) setIsLoadingData(false);
      });
    return () => { cancelled = true; };
  }, [currentUser]);

  useEffect(() => {
    if (settings.clinicName) {
      document.title = settings.clinicName;
    }
    if (settings.siteFavicon) {
      let link: HTMLLinkElement | null = document.querySelector("link[rel*='icon']");
      if (!link) {
        link = document.createElement('link');
        link.type = 'image/x-icon';
        link.rel = 'shortcut icon';
        document.getElementsByTagName('head')[0].appendChild(link);
      }
      link.href = settings.siteFavicon;
    }
  }, [settings.clinicName, settings.siteFavicon]);

  // Every handler below hits the API first. If a request fails (network
  // issue, expired session, denied permission), surface it instead of
  // failing silently so a clinic user knows a record wasn't actually saved.
  const withErrorAlert = <T extends any[]>(fn: (...args: T) => Promise<void>) => {
    return async (...args: T) => {
      try {
        await fn(...args);
      } catch (err: any) {
        alert(err?.message || 'حدث خطأ أثناء الاتصال بالخادم، حاول مرة أخرى');
      }
    };
  };

  const handleUpdateSettings = withErrorAlert(async (newSettings: ClinicSettings) => {
    const saved = await api.saveSettings(newSettings);
    setSettings(saved);
  });

  const handleAddPatient = withErrorAlert(async (patient: Omit<Patient, 'id' | 'createdAt'>) => {
    const newPatient = await api.addPatient(patient);
    setPatients(prev => [newPatient, ...prev]);
  });

  const handleAddAppointment = withErrorAlert(async (appointment: Omit<Appointment, 'id'>) => {
    const newApp = await api.addAppointment(appointment);
    setAppointments(prev => [newApp, ...prev]);
  });

  const handleUpdateAppointmentStatus = withErrorAlert(async (id: string, status: Appointment['status']) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    await api.updateAppointmentStatus(id, status);
  });

  const handleAddMedicalRecord = withErrorAlert(async (record: Omit<MedicalRecord, 'id'>) => {
    const newRec = await api.addMedicalRecord(record);
    setMedicalRecords(prev => [newRec, ...prev]);
  });

  const handleAddPrescription = withErrorAlert(async (prescription: Omit<Prescription, 'id'>) => {
    const newRx = await api.addPrescription(prescription);
    setPrescriptions(prev => [newRx, ...prev]);

    // The server already deducted stock atomically (server/routes.ts).
    // Mirror the same per-item deduction locally so the UI reflects it
    // immediately without an extra round trip.
    setMedicines(prev => prev.map(med => {
      const timesPrescribed = prescription.medications.filter(m => m.name === med.name).length;
      if (timesPrescribed === 0) return med;
      return { ...med, stock: Math.max(0, med.stock - timesPrescribed) };
    }));
  });

  const handleAddInvoice = withErrorAlert(async (invoice: Omit<Invoice, 'id'>) => {
    const newInv = await api.addInvoice(invoice);
    setInvoices(prev => [newInv, ...prev]);
  });

  const handleUpdateInvoiceStatus = withErrorAlert(async (id: string, status: Invoice['status'], paidAmount: number) => {
    setInvoices(prev => prev.map(i => i.id === id ? { ...i, status, paidAmount } : i));
    await api.updateInvoiceStatus(id, status, paidAmount);
  });

  const handleAddExpense = withErrorAlert(async (expense: Omit<Expense, 'id'>) => {
    const newExp = await api.addExpense(expense);
    setExpenses(prev => [newExp, ...prev]);
  });

  const handleDeleteExpense = withErrorAlert(async (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
    await api.deleteExpense(id);
  });

  const handleAddService = withErrorAlert(async (service: Omit<Service, 'id'>) => {
    const newSrv = await api.addService(service);
    setServices(prev => [...prev, newSrv]);
  });

  const handleDeleteService = withErrorAlert(async (id: string) => {
    setServices(prev => prev.filter(s => s.id !== id));
    await api.deleteService(id);
  });

  const handleAddMedicine = withErrorAlert(async (medicine: Omit<Medicine, 'id'>) => {
    const newMed = await api.addMedicine(medicine);
    setMedicines(prev => [...prev, newMed]);
  });

  const handleDeleteMedicine = withErrorAlert(async (id: string) => {
    setMedicines(prev => prev.filter(m => m.id !== id));
    await api.deleteMedicine(id);
  });

  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Permission enforcement: the sidebar only hides tabs a user can't see,
  // but activeTab can still be changed from elsewhere (e.g. Header's quick
  // action buttons). Enforce it here too so a user without a permission can
  // never actually render that view, not just fail to see its nav link.
  // The server enforces the same permissions independently on every write
  // (see server/auth.ts requirePermission) — this check is for the UI only.
  const canAccess = (tab: ActiveTab): boolean => {
    if (!currentUser) return false;
    if (!currentUser.permissions) return true;
    return !!currentUser.permissions[tab];
  };

  useEffect(() => {
    if (currentUser && !canAccess(activeTab)) {
      setActiveTab('dashboard');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser, activeTab]);

  if (!currentUser) {
    return <LoginView settings={settings} onLogin={setCurrentUser} />;
  }

  if (isLoadingData) {
    return (
      <div className="flex h-screen items-center justify-center bg-stone-50 text-stone-500 text-sm">
        جارِ تحميل بيانات العيادة...
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex h-screen items-center justify-center bg-stone-50 px-4">
        <div className="max-w-sm text-center">
          <p className="text-rose-600 font-semibold mb-2">تعذر الاتصال بالخادم</p>
          <p className="text-sm text-stone-500 mb-4">{loadError}</p>
          <button
            onClick={() => setCurrentUser({ ...currentUser })}
            className="px-4 py-2 rounded-xl bg-stone-900 text-white text-sm font-semibold"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  if (!canAccess(activeTab)) {
    // Permission check failed for the current tab; the effect above will
    // switch back to the dashboard on the next render. Render nothing
    // (rather than the unauthorized view) in the meantime.
    return null;
  }

  return (
    <div className="flex h-screen bg-stone-50 overflow-hidden" dir={settings.language === 'en' ? 'ltr' : 'rtl'}>
      {/* Sidebar Navigation */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        clinicName={settings.clinicName} 
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
        currentUser={currentUser}
        settings={settings}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden min-w-0">
        <Header 
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          patients={patients}
          onOpenNewAppointment={() => setActiveTab('appointments')}
          onOpenNewPatient={() => setActiveTab('patients')}
          onToggleSidebar={() => setIsMobileSidebarOpen(true)}
          currentUser={currentUser}
          onLogout={() => setCurrentUser(null)}
        />

        <main className="flex-1 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <DashboardView 
              patients={patients}
              appointments={appointments}
              invoices={invoices}
              expenses={expenses}
              setActiveTab={setActiveTab}
              settings={settings}
            />
          )}

          {activeTab === 'patients' && (
            <PatientsView 
              patients={patients}
              medicalRecords={medicalRecords}
              onAddPatient={handleAddPatient}
              settings={settings}
            />
          )}

          {activeTab === 'appointments' && (
            <AppointmentsView 
              appointments={appointments}
              patients={patients}
              settings={settings}
              onAddAppointment={handleAddAppointment}
              onUpdateStatus={handleUpdateAppointmentStatus}
            />
          )}

          {activeTab === 'records' && (
            <MedicalRecordsView 
              medicalRecords={medicalRecords}
              patients={patients}
              settings={settings}
              onAddRecord={handleAddMedicalRecord}
            />
          )}

          {activeTab === 'prescriptions' && (
            <PrescriptionsView 
              prescriptions={prescriptions}
              patients={patients}
              medicines={medicines}
              settings={settings}
              onAddPrescription={handleAddPrescription}
            />
          )}

          {activeTab === 'billing' && (
            <BillingView 
              invoices={invoices}
              patients={patients}
              settings={settings}
              onAddInvoice={handleAddInvoice}
              onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
            />
          )}

          {activeTab === 'expenses' && (
            <ExpensesView 
              expenses={expenses}
              settings={settings}
              onAddExpense={handleAddExpense}
              onDeleteExpense={handleDeleteExpense}
            />
          )}

          {activeTab === 'services' && (
            <ServicesView 
              services={services}
              settings={settings}
              onAddService={handleAddService}
              onDeleteService={handleDeleteService}
            />
          )}

          {activeTab === 'medicines' && (
            <MedicinesView 
              medicines={medicines}
              settings={settings}
              onAddMedicine={handleAddMedicine}
              onDeleteMedicine={handleDeleteMedicine}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView 
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
            />
          )}
        </main>
      </div>
    </div>
  );
}
