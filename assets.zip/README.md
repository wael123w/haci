# حكيم — نظام إدارة العيادات (React + PHP + MySQL)

## البنية
- الواجهة الأمامية: React + Vite + Tailwind (هذا المجلد الرئيسي، `src/`)
- الباك-إند: PHP خام + PDO + MySQL — بدون Node.js وبدون Composer، انظر
  [`backend-php/README.md`](backend-php/README.md) لتفاصيل النشر والتطوير

## التشغيل محلياً

**المتطلبات:** Node.js (للواجهة فقط) و PHP 8.1+‎ و MySQL (للباك-إند)

```bash
# الباك-إند
php -S localhost:8000 -t backend-php

# الواجهة (في نافذة طرفية أخرى)
npm install
npm run dev
```

## النشر على استضافة مشتركة

انظر [`backend-php/README.md`](backend-php/README.md) للخطوات الكاملة —
باختصار: `npm run build`، ثم رفع محتويات `dist/` و`backend-php/` معاً إلى
`public_html`، ثم زيارة `/install` من المتصفح لإكمال التثبيت بدون أي
Terminal أو phpMyAdmin.
